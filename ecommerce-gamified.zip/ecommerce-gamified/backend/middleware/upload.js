// ==================== backend/middleware/upload.js ====================
/**
 * 📤 MIDDLEWARE D'UPLOAD DE FICHIERS
 * 
 * Configure Multer pour gérer les uploads d'images
 * - Stockage sur disque dans le dossier 'uploads/'
 * - Filtrage des types de fichiers (images uniquement)
 * - Renommage avec timestamp
 * 
 * Usage dans les routes:
 * const upload = require('./middleware/upload');
 * 
 * router.post('/product', upload.single('image'), (req, res) => {
 *   console.log(req.file); // Informations du fichier uploadé
 *   console.log(req.file.filename); // Nom du fichier
 * });
 */

const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 📁 S'assurer que le dossier uploads existe
const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
  console.log('✅ Upload directory created:', uploadDir);
}

// 💾 Configuration du stockage
const storage = multer.diskStorage({
  /**
   * Définir la destination du fichier
   */
  destination: function (req, file, cb) {
    cb(null, uploadDir + '/');
  },
  
  /**
   * Définir le nom du fichier
   * Format: timestamp-originalname.ext
   * Ex: 1703851234567-product-image.jpg
   */
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    const nameWithoutExt = path.basename(file.originalname, ext);
    
    // Nettoyer le nom du fichier (enlever caractères spéciaux)
    const cleanName = nameWithoutExt
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .substring(0, 30); // Limiter à 30 caractères
    
    const filename = uniqueSuffix + '-' + cleanName + ext;
    cb(null, filename);
  }
});

// 🔍 Filtre des types de fichiers (images uniquement)
const fileFilter = (req, file, cb) => {
  // Types MIME acceptés
  const allowedTypes = [
    'image/png',
    'image/jpeg',
    'image/jpg',
    'image/webp',
    'image/gif'
  ];
  
  if (allowedTypes.includes(file.mimetype)) {
    // ✅ Type de fichier accepté
    cb(null, true);
  } else {
    // ❌ Type de fichier non supporté
    const error = new Error(
      `Format non supporté. Types acceptés: ${allowedTypes.join(', ')}`
    );
    error.code = 'INVALID_FILE_TYPE';
    cb(error, false);
  }
};

// ⚙️ Configuration de Multer
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // Limite: 5MB
    files: 1 // Maximum 1 fichier par upload (pour single)
  }
});

// 🚨 Gestionnaire d'erreurs pour Multer
const handleMulterError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Erreur Multer
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        msg: 'File too large',
        error: 'FILE_TOO_LARGE',
        maxSize: '5MB'
      });
    }
    
    if (err.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        msg: 'Too many files',
        error: 'TOO_MANY_FILES',
        maxFiles: 1
      });
    }
    
    return res.status(400).json({
      msg: 'Upload error',
      error: err.code
    });
  } else if (err) {
    // Autre erreur (fileFilter)
    if (err.code === 'INVALID_FILE_TYPE') {
      return res.status(400).json({
        msg: err.message,
        error: 'INVALID_FILE_TYPE',
        allowedTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif']
      });
    }
    
    return res.status(500).json({
      msg: 'Server error during upload',
      error: 'UPLOAD_ERROR'
    });
  }
  
  next();
};

// Export du middleware
module.exports = upload;
module.exports.handleMulterError = handleMulterError;