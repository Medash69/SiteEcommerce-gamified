// ==================== backend/middleware/admin.js ====================
/**
 * 👮 MIDDLEWARE DE VÉRIFICATION ADMIN
 * 
 * Vérifie que l'utilisateur authentifié a le rôle 'admin'
 * Doit être utilisé APRÈS le middleware auth
 * 
 * Usage dans les routes:
 * const auth = require('./middleware/auth');
 * const admin = require('./middleware/admin');
 * 
 * router.delete('/product/:id', auth, admin, (req, res) => {
 *   // Seulement accessible par les admins
 * });
 */

/**
 * Middleware de vérification admin
 * 
 * @param {Object} req - Requête Express (doit avoir req.role depuis auth middleware)
 * @param {Object} res - Réponse Express
 * @param {Function} next - Fonction next
 */
module.exports = function (req, res, next) {
  // 🔍 Vérifier si le rôle existe (signifie que auth middleware a été exécuté)
  if (!req.role) {
    return res.status(401).json({ 
      msg: 'Authentication required',
      error: 'NOT_AUTHENTICATED'
    });
  }
  
  // 👮 Vérifier si l'utilisateur est admin
  if (req.role !== 'admin') {
    return res.status(403).json({ 
      msg: 'Admin access required',
      error: 'FORBIDDEN',
      yourRole: req.role,
      requiredRole: 'admin'
    });
  }
  
  // ✅ L'utilisateur est admin, continuer
  next();
};