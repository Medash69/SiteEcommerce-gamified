// ==================== backend/middleware/auth.js ====================
/**
 * 🔐 MIDDLEWARE D'AUTHENTIFICATION
 * 
 * Vérifie le token JWT dans les headers de la requête
 * et ajoute les informations utilisateur (userId, role) à req
 * 
 * Usage dans les routes:
 * router.get('/protected', auth, (req, res) => {
 *   console.log(req.userId); // ID de l'utilisateur authentifié
 *   console.log(req.role);   // Rôle de l'utilisateur
 * });
 */

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'secret';

/**
 * Middleware d'authentification
 * 
 * @param {Object} req - Requête Express
 * @param {Object} res - Réponse Express
 * @param {Function} next - Fonction next
 */
module.exports = function (req, res, next) {
  // 📋 Récupérer le token depuis le header Authorization
  const authHeader = req.header('Authorization');
  
  // ❌ Vérifier si le token existe
  if (!authHeader) {
    return res.status(401).json({ 
      msg: 'No token, authorization denied',
      error: 'MISSING_TOKEN'
    });
  }
  
  try {
    // 🔍 Extraire le token (format: "Bearer TOKEN")
    const token = authHeader.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ 
        msg: 'Invalid token format',
        error: 'INVALID_FORMAT'
      });
    }
    
    // ✅ Vérifier et décoder le token
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // 📝 Ajouter les informations à la requête
    req.userId = decoded.id;
    req.role = decoded.role || 'user';
    
    // ⏭️ Continuer vers la prochaine fonction
    next();
  } catch (err) {
    // ❌ Token invalide ou expiré
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        msg: 'Token has expired',
        error: 'TOKEN_EXPIRED'
      });
    }
    
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ 
        msg: 'Token is invalid',
        error: 'INVALID_TOKEN'
      });
    }
    
    // Autre erreur
    return res.status(500).json({ 
      msg: 'Server error during authentication',
      error: 'AUTH_ERROR'
    });
  }
};