const mongoose = require('mongoose');

const BadgeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  tier: String, // Iron, Bronze, Silver, Gold, Platinum, Diamond, Legendary
  minPoints: { type: Number, required: true },
  reward: String,
  rewardType: String, // 'discount', 'free_shipping', 'free_product', 'vip'
  rewardValue: Number, // percentage or amount
  icon: String,
  color: String
});

module.exports = mongoose.model('Badge', BadgeSchema);
