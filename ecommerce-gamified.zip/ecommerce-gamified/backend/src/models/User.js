const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  age: Number,
  gender: String,
  
  // Classification Profile
  styleId: String,
  stylePreferences: {
    primary: String,      // Casual, Business, Sport, Tech
    secondary: [String],  // Array of secondary styles
  },
  
  // Gamification
  points: { type: Number, default: 100 },
  level: { type: Number, default: 1 },
  badges: [{ 
    name: String, 
    earnedAt: { type: Date, default: Date.now },
    tier: String 
  }],
  
  // Avatar System
  avatar: String,
  customAvatar: String, // URL for uploaded avatar
  
  // Behavioral Data for AI
  purchaseHistory: [{
    productId: mongoose.Schema.Types.ObjectId,
    category: String,
    price: Number,
    date: { type: Date, default: Date.now }
  }],
  
  viewHistory: [{
    productId: mongoose.Schema.Types.ObjectId,
    category: String,
    viewedAt: { type: Date, default: Date.now }
  }],
  
  // Engagement Metrics
  totalSpent: { type: Number, default: 0 },
  ordersCount: { type: Number, default: 0 },
  commentsCount: { type: Number, default: 0 },
  referralsCount: { type: Number, default: 0 },
  
  // Referral System
  referralCode: { type: String, unique: true },
  referredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  
  // Admin
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  
  cart: [{ 
    productId: mongoose.Schema.Types.ObjectId, 
    qty: Number 
  }],
  
  orders: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Order' 
  }]
}, { timestamps: true });

// Generate unique referral code before save
UserSchema.pre('save', function(next) {
  if (!this.referralCode) {
    this.referralCode = this.name.substring(0, 3).toUpperCase() + 
                        Math.random().toString(36).substring(2, 8).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('User', UserSchema);