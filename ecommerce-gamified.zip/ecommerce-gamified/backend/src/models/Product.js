const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  category: { type: String, required: true },
  subCategory: String,
  
  // Classification Tags for AI
  tags: [String], // ['casual', 'young', 'trendy', 'tech']
  targetAgeGroup: String, // 'Young', 'Adult', 'Senior'
  targetGender: String, // 'M', 'F', 'Unisex'
  styleType: String, // 'Casual', 'Business', 'Sport', 'Tech'
  
  image: String,
  images: [String], // Multiple images
  stock: { type: Number, default: 0 },
  
  // Analytics
  viewCount: { type: Number, default: 0 },
  purchaseCount: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  
  comments: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    user: String,
    text: String,
    rating: { type: Number, min: 1, max: 5 },
    date: { type: Date, default: Date.now }
  }],
  
  featured: { type: Boolean, default: false },
  active: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Product', ProductSchema);
