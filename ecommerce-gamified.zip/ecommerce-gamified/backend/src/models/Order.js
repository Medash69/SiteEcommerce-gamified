const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  
  items: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    title: String,
    price: Number,
    qty: Number,
    category: String
  }],
  
  subtotal: Number,
  discount: Number,
  discountCode: String,
  total: Number,
  
  pointsEarned: Number,
  pointsUsed: Number,
  
  status: { 
    type: String, 
    enum: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'],
    default: 'pending'
  },
  
  shippingAddress: {
    street: String,
    city: String,
    zipCode: String,
    country: String
  },
  
  paymentMethod: String,
  
}, { timestamps: true });

module.exports = mongoose.model('Order', OrderSchema);
