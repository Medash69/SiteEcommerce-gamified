// ==================== backend/src/utils/recommender.js ====================
/**
 * 🎯 SYSTÈME DE RECOMMANDATION SIMPLE
 * 
 * Module de compatibilité - Utilise le système avancé du classifier.js
 * mais garde une API simple pour la rétrocompatibilité
 */

/**
 * 📦 Recommandation simple basée sur le style
 * 
 * @param {Object} user - Utilisateur
 * @param {Array} products - Produits disponibles
 * @returns {Array} - Produits recommandés (max 6)
 */
function smartRecommend(user, products) {
  if (!user.styleId && !user.stylePreferences) {
    // Retourner les produits populaires si pas de profil
    return products
      .sort((a, b) => (b.purchaseCount || 0) - (a.purchaseCount || 0))
      .slice(0, 6);
  }
  
  // Extraire le style du styleId (ex: "Casual-Young-M" -> "Casual")
  const style = user.styleId 
    ? user.styleId.split('-')[0].toLowerCase() 
    : (user.stylePreferences?.primary || 'casual').toLowerCase();
  
  // Calculer le prix moyen de l'utilisateur
  const avgPrice = user.totalSpent && user.ordersCount 
    ? user.totalSpent / user.ordersCount 
    : 100;
  
  // Filtrer et scorer les produits
  const filtered = products.filter(p => {
    // Correspondance de style dans la catégorie
    const categoryMatch = p.category?.toLowerCase().includes(style);
    
    // Correspondance de prix (±50$ du prix moyen)
    const priceMatch = Math.abs(p.price - avgPrice) <= 50;
    
    // Correspondance de tags
    const tagMatch = p.tags?.some(tag => 
      tag.toLowerCase().includes(style)
    );
    
    return categoryMatch || priceMatch || tagMatch;
  });
  
  // Si pas assez de résultats, ajouter des produits populaires
  if (filtered.length < 6) {
    const additionalProducts = products
      .filter(p => !filtered.includes(p))
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, 6 - filtered.length);
    
    return [...filtered, ...additionalProducts].slice(0, 6);
  }
  
  return filtered.slice(0, 6);
}

/**
 * 🔥 Obtenir les produits tendance
 * 
 * @param {Array} products - Tous les produits
 * @param {Number} limit - Nombre de produits (défaut: 10)
 * @returns {Array} - Produits tendance
 */
function getTrendingProducts(products, limit = 10) {
  return products
    .filter(p => p.active)
    .sort((a, b) => {
      // Score composite: vues récentes + achats + note
      const scoreA = (a.viewCount || 0) * 0.3 + (a.purchaseCount || 0) * 0.5 + (a.rating || 0) * 0.2;
      const scoreB = (b.viewCount || 0) * 0.3 + (b.purchaseCount || 0) * 0.5 + (b.rating || 0) * 0.2;
      return scoreB - scoreA;
    })
    .slice(0, limit);
}

/**
 * ⭐ Obtenir les produits les mieux notés
 * 
 * @param {Array} products - Tous les produits
 * @param {Number} limit - Nombre de produits (défaut: 10)
 * @returns {Array} - Produits top rated
 */
function getTopRatedProducts(products, limit = 10) {
  return products
    .filter(p => p.active && p.rating >= 4)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, limit);
}

/**
 * 🆕 Obtenir les nouveaux produits
 * 
 * @param {Array} products - Tous les produits
 * @param {Number} limit - Nombre de produits (défaut: 10)
 * @returns {Array} - Nouveaux produits
 */
function getNewArrivals(products, limit = 10) {
  return products
    .filter(p => p.active)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, limit);
}

/**
 * 💎 Obtenir les produits premium
 * 
 * @param {Array} products - Tous les produits
 * @param {Number} limit - Nombre de produits (défaut: 10)
 * @returns {Array} - Produits premium
 */
function getPremiumProducts(products, limit = 10) {
  const avgPrice = products.reduce((sum, p) => sum + p.price, 0) / products.length;
  
  return products
    .filter(p => p.active && p.price > avgPrice * 1.5)
    .sort((a, b) => b.price - a.price)
    .slice(0, limit);
}

/**
 * 🎁 Recommandations pour cadeaux
 * 
 * @param {Object} criteria - Critères (budget, age, gender)
 * @param {Array} products - Tous les produits
 * @returns {Array} - Suggestions de cadeaux
 */
function getGiftRecommendations(criteria, products) {
  const { budget = 100, age = 30, gender = 'Unisex' } = criteria;
  
  return products
    .filter(p => p.active)
    .filter(p => p.price <= budget)
    .filter(p => {
      // Filtrer par démographique si spécifié dans le produit
      if (p.targetGender && p.targetGender !== 'Unisex') {
        return p.targetGender === gender;
      }
      return true;
    })
    .sort((a, b) => {
      // Priorité aux produits bien notés dans le budget
      const scoreA = (a.rating || 0) * 10 + (5 - Math.abs(a.price - budget * 0.8));
      const scoreB = (b.rating || 0) * 10 + (5 - Math.abs(b.price - budget * 0.8));
      return scoreB - scoreA;
    })
    .slice(0, 10);
}

/**
 * 🔄 Produits fréquemment achetés ensemble
 * 
 * @param {String} productId - ID du produit
 * @param {Object} Order - Modèle Order
 * @param {Array} allProducts - Tous les produits
 * @returns {Array} - Produits souvent achetés ensemble
 */
async function getFrequentlyBoughtTogether(productId, Order, allProducts) {
  try {
    // Trouver toutes les commandes contenant ce produit
    const ordersWithProduct = await Order.find({
      'items.productId': productId
    });
    
    // Compter les produits co-achetés
    const coProducts = {};
    
    ordersWithProduct.forEach(order => {
      order.items.forEach(item => {
        const itemId = item.productId.toString();
        if (itemId !== productId.toString()) {
          coProducts[itemId] = (coProducts[itemId] || 0) + 1;
        }
      });
    });
    
    // Trier par fréquence et retourner les produits
    const sortedCoProducts = Object.entries(coProducts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4)
      .map(([id]) => id);
    
    return allProducts.filter(p => 
      sortedCoProducts.includes(p._id.toString())
    );
  } catch (err) {
    console.error('Error getting frequently bought together:', err);
    return [];
  }
}

/**
 * 🎲 Produits similaires
 * 
 * @param {Object} product - Produit de référence
 * @param {Array} allProducts - Tous les produits
 * @param {Number} limit - Nombre de produits (défaut: 6)
 * @returns {Array} - Produits similaires
 */
function getSimilarProducts(product, allProducts, limit = 6) {
  return allProducts
    .filter(p => p._id.toString() !== product._id.toString())
    .filter(p => p.active)
    .map(p => {
      let similarityScore = 0;
      
      // Même catégorie (+5 points)
      if (p.category === product.category) similarityScore += 5;
      
      // Même sous-catégorie (+3 points)
      if (p.subCategory === product.subCategory) similarityScore += 3;
      
      // Prix similaire (+2 points si ±20%)
      const priceDiff = Math.abs(p.price - product.price) / product.price;
      if (priceDiff < 0.2) similarityScore += 2;
      
      // Tags communs (+1 par tag)
      if (product.tags && p.tags) {
        const commonTags = product.tags.filter(t => p.tags.includes(t));
        similarityScore += commonTags.length;
      }
      
      // Même style (+3 points)
      if (p.styleType === product.styleType) similarityScore += 3;
      
      return { ...p, similarityScore };
    })
    .sort((a, b) => b.similarityScore - a.similarityScore)
    .slice(0, limit);
}

/**
 * 🎯 Recommandations basées sur le panier
 * 
 * @param {Array} cartItems - Articles dans le panier
 * @param {Array} allProducts - Tous les produits
 * @returns {Array} - Recommandations basées sur le panier
 */
function getCartBasedRecommendations(cartItems, allProducts) {
  if (!cartItems || cartItems.length === 0) return [];
  
  // Extraire les catégories et styles du panier
  const cartCategories = new Set();
  const cartStyles = new Set();
  let avgCartPrice = 0;
  
  cartItems.forEach(item => {
    if (item.category) cartCategories.add(item.category);
    if (item.styleType) cartStyles.add(item.styleType);
    avgCartPrice += item.price || 0;
  });
  
  avgCartPrice = avgCartPrice / cartItems.length;
  
  // Trouver des produits complémentaires
  return allProducts
    .filter(p => p.active)
    .filter(p => !cartItems.some(item => item._id.toString() === p._id.toString()))
    .map(p => {
      let score = 0;
      
      // Catégorie compatible
      if (cartCategories.has(p.category)) score += 3;
      
      // Style compatible
      if (cartStyles.has(p.styleType)) score += 2;
      
      // Prix dans la même gamme
      if (Math.abs(p.price - avgCartPrice) < avgCartPrice * 0.5) score += 2;
      
      return { ...p, complementScore: score };
    })
    .sort((a, b) => b.complementScore - a.complementScore)
    .slice(0, 6);
}

module.exports = {
  smartRecommend,
  getTrendingProducts,
  getTopRatedProducts,
  getNewArrivals,
  getPremiumProducts,
  getGiftRecommendations,
  getFrequentlyBoughtTogether,
  getSimilarProducts,
  getCartBasedRecommendations
};