// ==================== backend/src/utils/classifier.js ====================
/**
 * 🤖 SYSTÈME IA DE CLASSIFICATION
 * 
 * Ce module implémente un système d'IA basé sur des règles (Rule-Based AI)
 * pour classifier les utilisateurs et recommander des produits.
 * 
 * FONCTIONNEMENT:
 * 1. Analyse multi-critères: âge, genre, styles, intérêts
 * 2. Scoring pondéré pour chaque style
 * 3. Génération d'un Style ID unique (ex: "Casual-Young-M")
 * 4. Recommandations basées sur similarité et historique
 */

// 🎨 Définition des Profils de Style
const STYLE_PROFILES = {
  'Casual': {
    keywords: ['casual', 'comfortable', 'everyday', 'relaxed', 'simple'],
    ageGroups: ['Young', 'Adult'],
    categories: ['T-shirts', 'Jeans', 'Sneakers', 'Casual', 'Streetwear'],
    icon: '👕',
    color: '#3B82F6'
  },
  'Business': {
    keywords: ['professional', 'formal', 'office', 'elegant', 'corporate'],
    ageGroups: ['Adult', 'Senior'],
    categories: ['Suits', 'Dress Shirts', 'Business', 'Formal', 'Ties'],
    icon: '💼',
    color: '#1F2937'
  },
  'Sport': {
    keywords: ['athletic', 'active', 'fitness', 'outdoor', 'running'],
    ageGroups: ['Young', 'Adult'],
    categories: ['Sportswear', 'Athletic', 'Outdoor', 'Fitness', 'Running'],
    icon: '⚽',
    color: '#10B981'
  },
  'Tech': {
    keywords: ['gadgets', 'electronics', 'gaming', 'tech', 'digital'],
    ageGroups: ['Young', 'Adult'],
    categories: ['Electronics', 'Computers', 'Gaming', 'Tech', 'Accessories'],
    icon: '💻',
    color: '#6366F1'
  },
  'Elegant': {
    keywords: ['luxury', 'premium', 'sophisticated', 'chic', 'designer'],
    ageGroups: ['Adult', 'Senior'],
    categories: ['Designer', 'Luxury', 'Premium', 'Fashion', 'Accessories'],
    icon: '💎',
    color: '#EC4899'
  },
  'Trendy': {
    keywords: ['fashion', 'trendy', 'stylish', 'modern', 'instagram'],
    ageGroups: ['Young'],
    categories: ['Fashion', 'Accessories', 'Trendy', 'Modern', 'Street'],
    icon: '✨',
    color: '#F59E0B'
  }
};

/**
 * 🔢 Déterminer le groupe d'âge
 */
function getAgeGroup(age) {
  if (age <= 25) return 'Young';
  if (age <= 45) return 'Adult';
  return 'Senior';
}

/**
 * 🔤 Obtenir le code genre
 */
function getGenderCode(gender) {
  if (!gender) return 'U';
  const g = gender.toUpperCase();
  if (g === 'M' || g === 'MALE' || g === 'HOMME') return 'M';
  if (g === 'F' || g === 'FEMALE' || g === 'FEMME') return 'F';
  return 'U';
}

/**
 * 🎯 FONCTION PRINCIPALE DE CLASSIFICATION
 * 
 * Cette fonction analyse les données utilisateur et génère un profil complet
 * avec un Style ID unique utilisé pour personnaliser l'expérience
 * 
 * @param {Object} userData - Données utilisateur (age, gender, styles, interests)
 * @returns {Object} - Profil de classification complet
 */
function classifyUser(userData) {
  const { age, gender, styles = [], interests = [] } = userData;
  
  const ageGroup = getAgeGroup(age);
  const genderCode = getGenderCode(gender);
  
  // 📊 Calculer le score de chaque style
  const styleScores = {};
  
  Object.keys(STYLE_PROFILES).forEach(style => {
    let score = 0;
    const profile = STYLE_PROFILES[style];
    
    // ✅ Compatibilité d'âge (+2 points)
    if (profile.ageGroups.includes(ageGroup)) {
      score += 2;
    }
    
    // ✅ Style sélectionné directement (+5 points)
    if (styles.includes(style)) {
      score += 5;
    }
    
    // ✅ Correspondance des mots-clés dans les intérêts (+1 point par match)
    interests.forEach(interest => {
      profile.keywords.forEach(keyword => {
        if (interest.toLowerCase().includes(keyword)) {
          score += 1;
        }
      });
    });
    
    styleScores[style] = score;
  });
  
  // 🏆 Trier les styles par score décroissant
  const sortedStyles = Object.entries(styleScores)
    .sort((a, b) => b[1] - a[1])
    .map(([style]) => style);
  
  const primary = sortedStyles[0] || 'Casual';
  const secondary = sortedStyles.slice(1, 3);
  
  // 🆔 Générer le Style ID unique
  const styleId = `${primary}-${ageGroup}-${genderCode}`;
  
  return {
    styleId,
    primary,
    secondary,
    ageGroup,
    genderCode,
    scores: styleScores,
    profileData: STYLE_PROFILES[primary]
  };
}

/**
 * ⭐ SCORING DES PRODUITS POUR RECOMMANDATIONS
 * 
 * Calcule un score de pertinence pour chaque produit basé sur:
 * - Correspondance de style (primaire et secondaire)
 * - Gamme de prix (basée sur historique)
 * - Démographique cible
 * - Popularité
 * - Note moyenne
 * 
 * @param {Object} product - Produit à scorer
 * @param {Object} user - Utilisateur avec historique
 * @returns {Number} - Score de pertinence (0-100)
 */
function scoreProduct(product, user) {
  let score = 0;
  
  if (!user.stylePreferences) return score;
  
  const { primary, secondary = [] } = user.stylePreferences;
  const allStyles = [primary, ...secondary];
  
  // 🎨 Correspondance de catégorie (+5 primaire, +2 secondaire)
  allStyles.forEach((style, index) => {
    const profile = STYLE_PROFILES[style];
    if (profile) {
      profile.categories.forEach(cat => {
        if (product.category && product.category.toLowerCase().includes(cat.toLowerCase())) {
          score += index === 0 ? 5 : 2;
        }
        if (product.subCategory && product.subCategory.toLowerCase().includes(cat.toLowerCase())) {
          score += index === 0 ? 3 : 1;
        }
      });
      
      // 🏷️ Correspondance de tags (+2 par tag)
      if (product.tags) {
        product.tags.forEach(tag => {
          if (profile.keywords.includes(tag.toLowerCase())) {
            score += 2;
          }
        });
      }
    }
  });
  
  // 💰 Correspondance de gamme de prix (+3 si proche)
  if (user.purchaseHistory && user.purchaseHistory.length > 0) {
    const avgPrice = user.purchaseHistory.reduce((sum, p) => sum + p.price, 0) / user.purchaseHistory.length;
    const priceDiff = Math.abs(product.price - avgPrice);
    const priceRatio = priceDiff / avgPrice;
    
    if (priceRatio < 0.3) {
      score += 3;
    } else if (priceRatio < 0.5) {
      score += 1;
    }
  }
  
  // 👥 Correspondance démographique (+2 par critère)
  if (user.stylePreferences.ageGroup) {
    if (product.targetAgeGroup === user.stylePreferences.ageGroup) {
      score += 2;
    }
  }
  
  if (user.gender) {
    if (product.targetGender === user.gender || product.targetGender === 'Unisex') {
      score += 2;
    }
  }
  
  // 📈 Boost de popularité (+1 si populaire)
  if (product.purchaseCount > 10) {
    score += 1;
  }
  
  // ⭐ Boost de qualité (+1 si bien noté)
  if (product.rating >= 4) {
    score += 1;
  }
  
  // 🌟 Produits mis en avant (+1)
  if (product.featured) {
    score += 1;
  }
  
  return score;
}

/**
 * 🎁 OBTENIR LES RECOMMANDATIONS PERSONNALISÉES
 * 
 * Génère une liste de produits recommandés basée sur le profil utilisateur
 * 
 * @param {Object} user - Utilisateur avec préférences
 * @param {Array} allProducts - Tous les produits disponibles
 * @param {Number} limit - Nombre de recommandations (défaut: 10)
 * @returns {Array} - Produits recommandés triés par pertinence
 */
function getRecommendations(user, allProducts, limit = 10) {
  // Si pas de préférences, retourner les produits populaires
  if (!user.stylePreferences) {
    return allProducts
      .filter(p => p.active)
      .sort((a, b) => b.purchaseCount - a.purchaseCount)
      .slice(0, limit);
  }
  
  // Filtrer les produits déjà achetés
  const purchasedIds = (user.purchaseHistory || []).map(p => p.productId.toString());
  const availableProducts = allProducts.filter(p => 
    p.active && !purchasedIds.includes(p._id.toString())
  );
  
  // Scorer et trier les produits
  const scoredProducts = availableProducts.map(product => ({
    ...product.toObject(),
    relevanceScore: scoreProduct(product, user)
  }));
  
  // Trier par score décroissant et retourner top N
  return scoredProducts
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, limit);
}

/**
 * 🤝 FILTRAGE COLLABORATIF SIMPLE
 * 
 * Trouve des utilisateurs similaires basé sur le profil
 */
function getSimilarUsers(currentUser, allUsers, limit = 5) {
  if (!currentUser.stylePreferences) return [];
  
  const similarUsers = allUsers
    .filter(u => u._id.toString() !== currentUser._id.toString())
    .filter(u => u.stylePreferences && u.stylePreferences.primary === currentUser.stylePreferences.primary)
    .filter(u => Math.abs((u.age || 0) - (currentUser.age || 0)) <= 10)
    .slice(0, limit);
  
  return similarUsers;
}

/**
 * 🎯 RECOMMANDATIONS COLLABORATIVES
 * 
 * Recommande des produits basés sur ce que des utilisateurs similaires ont acheté
 */
function getCollaborativeRecommendations(user, allUsers, allProducts, limit = 5) {
  const similarUsers = getSimilarUsers(user, allUsers);
  
  if (similarUsers.length === 0) return [];
  
  // Agréger les achats des utilisateurs similaires
  const recommendedProductIds = new Set();
  
  similarUsers.forEach(similarUser => {
    if (similarUser.purchaseHistory) {
      similarUser.purchaseHistory.forEach(purchase => {
        recommendedProductIds.add(purchase.productId.toString());
      });
    }
  });
  
  // Filtrer les produits déjà achetés par l'utilisateur actuel
  const currentUserPurchases = (user.purchaseHistory || []).map(p => p.productId.toString());
  
  const recommendations = allProducts
    .filter(p => recommendedProductIds.has(p._id.toString()))
    .filter(p => !currentUserPurchases.includes(p._id.toString()))
    .filter(p => p.active)
    .slice(0, limit);
  
  return recommendations;
}

/**
 * 📊 OBTENIR LES STATISTIQUES DE CLASSIFICATION
 */
function getClassificationStats(users) {
  const stats = {
    totalUsers: users.length,
    styleDistribution: {},
    ageDistribution: {},
    genderDistribution: {}
  };
  
  users.forEach(user => {
    if (user.stylePreferences) {
      const style = user.stylePreferences.primary;
      stats.styleDistribution[style] = (stats.styleDistribution[style] || 0) + 1;
      
      const age = user.stylePreferences.ageGroup;
      stats.ageDistribution[age] = (stats.ageDistribution[age] || 0) + 1;
    }
    
    if (user.gender) {
      stats.genderDistribution[user.gender] = (stats.genderDistribution[user.gender] || 0) + 1;
    }
  });
  
  return stats;
}

module.exports = {
  classifyUser,
  getRecommendations,
  scoreProduct,
  getSimilarUsers,
  getCollaborativeRecommendations,
  getClassificationStats,
  STYLE_PROFILES
};