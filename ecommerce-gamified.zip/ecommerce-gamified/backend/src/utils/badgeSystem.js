// ==================== backend/src/utils/badgeSystem.js ====================
/**
 * 🏆 SYSTÈME DE BADGES ET GAMIFICATION
 * 
 * Gère la progression des utilisateurs à travers 12 niveaux de badges
 * avec des récompenses croissantes
 */

const Badge = require('../models/Badge');

// 🎖️ Définition des 12 niveaux de badges avec images Google
const BADGE_TIERS = [
  {
    name: 'Iron 1',
    tier: 'Iron',
    minPoints: 0,
    reward: 'None',
    rewardType: 'none',
    rewardValue: 0,
    icon: 'https://img.icons8.com/color/96/000000/iron-man.png',
    color: '#78716c',
    description: 'Bienvenue ! Commencez votre aventure'
  },
  {
    name: 'Iron 2',
    tier: 'Iron',
    minPoints: 200,
    reward: 'None',
    rewardType: 'none',
    rewardValue: 0,
    icon: 'https://img.icons8.com/color/96/000000/iron-man.png',
    color: '#78716c',
    description: 'Continuez comme ça !'
  },
  {
    name: 'Iron 3',
    tier: 'Iron',
    minPoints: 500,
    reward: 'None',
    rewardType: 'none',
    rewardValue: 0,
    icon: 'https://img.icons8.com/color/96/000000/iron-man.png',
    color: '#78716c',
    description: 'Presque au Bronze !'
  },
  {
    name: 'Bronze 1',
    tier: 'Bronze',
    minPoints: 1000,
    reward: '50% Shipping Discount',
    rewardType: 'shipping',
    rewardValue: 0.5,
    icon: 'https://img.icons8.com/color/96/000000/bronze-medal.png',
    color: '#cd7f32',
    description: 'Premier vrai palier - Réduction livraison !'
  },
  {
    name: 'Bronze 3',
    tier: 'Bronze',
    minPoints: 2000,
    reward: '90% Shipping Discount',
    rewardType: 'shipping',
    rewardValue: 0.9,
    icon: 'https://img.icons8.com/color/96/000000/bronze-medal.png',
    color: '#cd7f32',
    description: 'Livraison presque gratuite !'
  },
  {
    name: 'Silver 1',
    tier: 'Silver',
    minPoints: 3000,
    reward: '5% Discount',
    rewardType: 'discount',
    rewardValue: 5,
    icon: 'https://img.icons8.com/color/96/000000/silver-medal.png',
    color: '#c0c0c0',
    description: 'Première réduction sur vos achats'
  },
  {
    name: 'Gold 1',
    tier: 'Gold',
    minPoints: 7000,
    reward: '5% Discount + Free Shipping',
    rewardType: 'both',
    rewardValue: 5,
    icon: 'https://img.icons8.com/color/96/000000/gold-medal.png',
    color: '#ffd700',
    description: 'Membre Gold - Privilèges premium'
  },
  {
    name: 'Gold 3',
    tier: 'Gold',
    minPoints: 12000,
    reward: '10% Discount + Free Shipping',
    rewardType: 'both',
    rewardValue: 10,
    icon: 'https://img.icons8.com/color/96/000000/gold-medal.png',
    color: '#ffd700',
    description: '10% sur tout + Livraison offerte'
  },
  {
    name: 'Platinum 1',
    tier: 'Platinum',
    minPoints: 20000,
    reward: 'Free Product ($100 max)',
    rewardType: 'free_product',
    rewardValue: 100,
    icon: 'https://img.icons8.com/color/96/000000/platinum.png',
    color: '#e5e4e2',
    description: 'Client VIP - Produit gratuit !'
  },
  {
    name: 'Platinum 3',
    tier: 'Platinum',
    minPoints: 35000,
    reward: 'Free Product ($200 max)',
    rewardType: 'free_product',
    rewardValue: 200,
    icon: 'https://img.icons8.com/color/96/000000/platinum.png',
    color: '#e5e4e2',
    description: 'Elite - Produit premium gratuit'
  },
  {
    name: 'Diamond',
    tier: 'Diamond',
    minPoints: 50000,
    reward: '3 Free Gifts ($500 max total)',
    rewardType: 'gifts',
    rewardValue: 500,
    icon: 'https://img.icons8.com/color/96/000000/diamond.png',
    color: '#b9f2ff',
    description: 'Diamond - Cadeaux exclusifs'
  },
  {
    name: 'Legendary',
    tier: 'Legendary',
    minPoints: 100000,
    reward: 'VIP Access + All Benefits',
    rewardType: 'vip',
    rewardValue: 0,
    icon: 'https://img.icons8.com/color/96/000000/crown.png',
    color: '#ff6b6b',
    description: 'Statut légendaire - Accès VIP ultime'
  }
];

/**
 * 🎯 Déterminer le badge actuel basé sur les points
 * 
 * @param {Number} points - Points de l'utilisateur
 * @returns {Object} - Badge actuel
 */
async function computeBadge(points) {
  let currentBadge = BADGE_TIERS[0];
  
  for (const badge of BADGE_TIERS) {
    if (points >= badge.minPoints) {
      currentBadge = badge;
    } else {
      break;
    }
  }
  
  return currentBadge;
}

/**
 * 🎁 Obtenir le prochain badge à débloquer
 * 
 * @param {Number} points - Points actuels
 * @returns {Object|null} - Prochain badge ou null si niveau max
 */
function getNextBadge(points) {
  for (const badge of BADGE_TIERS) {
    if (points < badge.minPoints) {
      return {
        badge,
        pointsNeeded: badge.minPoints - points
      };
    }
  }
  return null; // Niveau maximum atteint
}

/**
 * 📊 Calculer la progression vers le prochain badge
 * 
 * @param {Number} points - Points actuels
 * @returns {Object} - Infos de progression
 */
function getBadgeProgress(points) {
  const current = BADGE_TIERS.find((b, i) => {
    const next = BADGE_TIERS[i + 1];
    return points >= b.minPoints && (!next || points < next.minPoints);
  }) || BADGE_TIERS[0];
  
  const next = getNextBadge(points);
  
  if (!next) {
    return { current, next: null, progress: 100, pointsNeeded: 0 };
  }
  
  const pointsInCurrentTier = points - current.minPoints;
  const pointsNeededForNext = next.badge.minPoints - current.minPoints;
  const progress = (pointsInCurrentTier / pointsNeededForNext) * 100;
  
  return {
    current,
    next: next.badge,
    pointsNeeded: next.pointsNeeded,
    progress: Math.min(Math.max(progress, 0), 100)
  };
}

/**
 * 🎁 Obtenir les récompenses disponibles pour un badge
 * 
 * @param {Object} badge - Badge
 * @returns {Object} - Détails des récompenses
 */
function getBadgeRewards(badge) {
  const rewards = {
    hasDiscount: false,
    discountPercent: 0,
    hasFreeShipping: false,
    hasFreeProduct: false,
    freeProductValue: 0,
    hasGifts: false,
    giftsValue: 0,
    isVIP: false
  };
  
  switch (badge.rewardType) {
    case 'discount':
      rewards.hasDiscount = true;
      rewards.discountPercent = badge.rewardValue;
      break;
      
    case 'shipping':
      rewards.hasFreeShipping = badge.rewardValue >= 0.9;
      break;
      
    case 'both':
      rewards.hasDiscount = true;
      rewards.discountPercent = badge.rewardValue;
      rewards.hasFreeShipping = true;
      break;
      
    case 'free_product':
      rewards.hasFreeProduct = true;
      rewards.freeProductValue = badge.rewardValue;
      break;
      
    case 'gifts':
      rewards.hasGifts = true;
      rewards.giftsValue = badge.rewardValue;
      break;
      
    case 'vip':
      rewards.isVIP = true;
      rewards.hasDiscount = true;
      rewards.discountPercent = 20;
      rewards.hasFreeShipping = true;
      break;
  }
  
  return rewards;
}

/**
 * 🏅 Vérifier si un utilisateur a débloqué un nouveau badge
 * 
 * @param {Number} oldPoints - Points avant action
 * @param {Number} newPoints - Points après action
 * @returns {Object|null} - Nouveau badge débloqué ou null
 */
async function checkBadgeUnlock(oldPoints, newPoints) {
  const oldBadge = await computeBadge(oldPoints);
  const newBadge = await computeBadge(newPoints);
  
  if (oldBadge.name !== newBadge.name) {
    return {
      unlocked: true,
      badge: newBadge,
      message: `🎉 Félicitations ! Vous avez atteint le niveau ${newBadge.name} !`,
      rewards: getBadgeRewards(newBadge)
    };
  }
  
  return null;
}

/**
 * 📈 Calculer les points gagnés par action
 */
const POINT_REWARDS = {
  REGISTER: 100,
  QUIZ: 100,
  COMMENT: 50,
  REFERRAL: 200,
  PURCHASE_RATIO: 0.1, // 1 point par $10
  DAILY_LOGIN: 10,
  SHARE_SOCIAL: 25,
  REVIEW_PRODUCT: 75
};

/**
 * 💰 Calculer les points pour un achat
 * 
 * @param {Number} amount - Montant de l'achat
 * @returns {Number} - Points gagnés
 */
function calculatePurchasePoints(amount) {
  return Math.floor(amount * POINT_REWARDS.PURCHASE_RATIO);
}

/**
 * 🎮 Initialiser les badges dans la base de données
 */
async function initializeBadges() {
  try {
    const count = await Badge.countDocuments();
    if (count === 0) {
      await Badge.insertMany(BADGE_TIERS);
      console.log('✅ Badges initialized successfully');
    } else {
      console.log('ℹ️  Badges already initialized');
    }
  } catch (err) {
    console.error('❌ Error initializing badges:', err);
  }
}

/**
 * 📊 Obtenir tous les badges disponibles
 */
async function getAllBadges() {
  try {
    return await Badge.find().sort({ minPoints: 1 });
  } catch (err) {
    return BADGE_TIERS;
  }
}

/**
 * 🎯 Calculer le niveau utilisateur basé sur les points
 * (Niveau = Badge tier + sous-niveau)
 */
function calculateUserLevel(points) {
  const badge = BADGE_TIERS.find((b, i) => {
    const next = BADGE_TIERS[i + 1];
    return points >= b.minPoints && (!next || points < next.minPoints);
  }) || BADGE_TIERS[0];
  
  const tierIndex = BADGE_TIERS.findIndex(b => b.name === badge.name);
  return tierIndex + 1;
}

/**
 * 🏆 Obtenir le classement d'un utilisateur parmi tous
 */
async function getUserRanking(userId, User) {
  try {
    const allUsers = await User.find().select('_id points').sort({ points: -1 });
    const rank = allUsers.findIndex(u => u._id.toString() === userId.toString()) + 1;
    return {
      rank,
      total: allUsers.length,
      percentile: Math.round((1 - rank / allUsers.length) * 100)
    };
  } catch (err) {
    return null;
  }
}

module.exports = {
  computeBadge,
  getNextBadge,
  getBadgeProgress,
  getBadgeRewards,
  checkBadgeUnlock,
  calculatePurchasePoints,
  initializeBadges,
  getAllBadges,
  calculateUserLevel,
  getUserRanking,
  BADGE_TIERS,
  POINT_REWARDS
};