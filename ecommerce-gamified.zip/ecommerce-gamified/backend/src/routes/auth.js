const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'secret';

// Register
router.post('/register', async (req,res)=>{
  try{
    const {name,email,password,age,gender} = req.body;
    let user = await User.findOne({email});
    if(user) return res.status(400).json({msg:'Email exists'});
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    user = new User({name,email,password:hash,age,gender,points:100}); // give initial points
    await user.save();
    const token = jwt.sign({id:user._id}, JWT_SECRET, {expiresIn:'7d'});
    res.json({token, user});
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Login
router.post('/login', async (req,res)=>{
  try{
    const {email,password} = req.body;
    const user = await User.findOne({email});
    if(!user) return res.status(400).json({msg:'User not found'});
    const isMatch = await bcrypt.compare(password, user.password);
    if(!isMatch) return res.status(400).json({msg:'Invalid credentials'});
    const token = jwt.sign({id:user._id}, JWT_SECRET, {expiresIn:'7d'});
    res.json({token, user});
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

module.exports = router;