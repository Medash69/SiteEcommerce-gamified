const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Product = require('../models/Product');
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

function auth(req,res,next){
  const token = req.headers['authorization']?.split(' ')[1];
  if(!token) return res.status(401).json({msg:'No token'});
  try{
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id;
    next();
  }catch(e){ return res.status(401).json({msg:'Token invalid'}); }
}

// get profile
router.get('/me', auth, async (req,res)=>{
  const user = await User.findById(req.userId);
  res.json(user);
});

// take quiz and assign styleId + award points
router.post('/quiz', auth, async (req,res)=>{
  const {age, gender, style} = req.body;
  const user = await User.findById(req.userId);
  // rule-based style id
  const ageGroup = age <=25 ? 'Young' : (age<=45? 'Adult':'Senior');
  const styleId = `${style}-${ageGroup}-${gender?.charAt(0) || 'U'}`;
  user.styleId = styleId;
  user.points = (user.points || 0) + 100; // quiz points
  // assign basic avatar by style
  user.avatar = `/avatars/${styleId}.png`;
  await user.save();
  res.json({ok:true, user});
});

// add comment -> award points (simulated)
router.post('/comment', auth, async (req,res)=>{
  const {productId, text} = req.body;
  const user = await User.findById(req.userId);
  user.points = (user.points || 0) + 50;
  await user.save();
  res.json({ok:true, points:user.points});
});

// get recommendations (simple rule-based based on styleId)
router.get('/recommendations', auth, async (req,res)=>{
  const user = await User.findById(req.userId);
  if(!user || !user.styleId) return res.json([]);
  const style = user.styleId.split('-')[0];
  // recommend by category matching style token
  const products = await Product.find({ category: new RegExp(style, 'i') }).limit(10);
  res.json(products);
});

router.post('/avatar', auth, async (req, res) => {
  const { avatar } = req.body;
  const user = await User.findById(req.userId);
  user.avatar = avatar;
  await user.save();
  res.json({ ok: true, avatar });
});


module.exports = router;