const express = require("express");
const router = express.Router();
const Product = require("../models/Product");
const auth = require("../../middleware/auth");
const admin = require("../../middleware/admin");
const upload = require("../../middleware/upload");

// UPDATE PRODUCT
router.put("/product/:id", auth, admin, upload.single("image"), async (req, res) => {
    const { title, price, description, category } = req.body;

    const update = { title, price, description, category };
    if (req.file) update.image = "/uploads/" + req.file.filename;

    const p = await Product.findByIdAndUpdate(req.params.id, update, { new: true });
    res.json(p);
});

// DELETE PRODUCT
router.delete("/product/:id", auth, admin, async (req, res) => {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
});

module.exports = router;
