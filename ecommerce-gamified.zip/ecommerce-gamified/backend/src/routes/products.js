const express = require("express");
const router = express.Router();
const Product = require("../models/Product");
const upload = require("../../middleware/upload");

// GET ALL + FILTERS
router.get("/", async (req, res) => {
    const { q, category, min, max, sort } = req.query;

    let filters = {};

    if (q) filters.title = new RegExp(q, "i");
    if (category) filters.category = category;

    if (min || max) {
        filters.price = {};
        if (min) filters.price.$gte = min;
        if (max) filters.price.$lte = max;
    }

    let query = Product.find(filters);

    if (sort === "price_asc") query.sort({ price: 1 });
    if (sort === "price_desc") query.sort({ price: -1 });
    if (sort === "new") query.sort({ createdAt: -1 });

    const products = await query.exec();
    res.json(products);
});

// GET SINGLE
router.get("/:id", async (req, res) => {
    const p = await Product.findById(req.params.id);
    res.json(p);
});

// ADD PRODUCT (ADMIN)
router.post("/admin/add", upload.single("image"), async (req, res) => {
    const { title, price, category, description } = req.body;

    const product = new Product({
        title,
        price,
        description,
        category,
        image: req.file ? "/uploads/" + req.file.filename : null
    });

    await product.save();
    res.json(product);
});

// ADD COMMENT
router.post("/:id/comment", async (req, res) => {
    const { user, text } = req.body;
    const p = await Product.findById(req.params.id);

    p.comments.push({ user, text });
    await p.save();

    res.json(p.comments);
});

module.exports = router;
