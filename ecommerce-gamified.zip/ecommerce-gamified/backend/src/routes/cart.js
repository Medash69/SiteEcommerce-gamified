const express = require("express");
const router = express.Router();
const Cart = require("../models/Cart");
const Product = require("../models/Product");
const auth = require("../../middleware/auth");

router.get("/", auth, async (req, res) => {
    const cart = await Cart.findOne({ userId: req.userId }).populate("items.productId");
    res.json(cart || { items: [] });
});

// ADD ITEM
router.post("/add", auth, async (req, res) => {
    const { productId, qty } = req.body;

    let cart = await Cart.findOne({ userId: req.userId });
    const product = await Product.findById(productId);

    if (!cart) {
        cart = new Cart({
            userId: req.userId,
            items: [],
            total: 0
        });
    }

    const exists = cart.items.find(i => i.productId == productId);

    if (exists) exists.qty += qty;
    else cart.items.push({
        productId,
        qty,
        price: product.price
    });

    cart.total = cart.items.reduce((a, i) => a + i.price * i.qty, 0);

    await cart.save();

    res.json(cart);
});

// REMOVE ITEM
router.delete("/remove/:id", auth, async (req, res) => {
    const cart = await Cart.findOne({ userId: req.userId });
    cart.items = cart.items.filter(i => i.productId != req.params.id);
    cart.total = cart.items.reduce((a, i) => a + i.price * i.qty, 0);
    await cart.save();
    res.json(cart);
});

module.exports = router;
