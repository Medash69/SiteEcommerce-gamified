// ==================== backend/scripts/seed.js ====================
/**
 * 🌱 SCRIPT DE SEED - Initialisation de la base de données
 * 
 * Ce script peuple la base de données avec:
 * - Produits d'exemple (avec images Unsplash)
 * - Utilisateurs de test (admin et user)
 * - Badges système
 * 
 * Usage: node scripts/seed.js
 */

const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const Product = require('../src/models/Product');
const User = require('../src/models/User');
const bcrypt = require('bcryptjs');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce_gamified';

// 🖼️ Produits avec images Unsplash de haute qualité
const sampleProducts = [
  // 👕 CASUAL
  {
    title: 'Classic White T-Shirt',
    description: 'Comfortable premium cotton t-shirt perfect for everyday wear. Soft fabric, modern fit.',
    price: 29.99,
    category: 'Clothing',
    subCategory: 'T-Shirts',
    styleType: 'Casual',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['casual', 'comfortable', 'everyday', 'cotton'],
    stock: 100,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800',
    featured: true,
    rating: 4.5
  },
  {
    title: 'Blue Denim Jeans',
    description: 'Classic blue jeans with modern slim fit. Durable denim, comfortable all day.',
    price: 79.99,
    category: 'Clothing',
    subCategory: 'Jeans',
    styleType: 'Casual',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['casual', 'denim', 'comfortable', 'classic'],
    stock: 80,
    image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=800',
    rating: 4.7
  },
  {
    title: 'Casual Sneakers',
    description: 'Comfortable sneakers for everyday adventures. Lightweight and stylish.',
    price: 89.99,
    category: 'Footwear',
    subCategory: 'Sneakers',
    styleType: 'Casual',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['casual', 'comfortable', 'sneakers', 'sport'],
    stock: 60,
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800',
    featured: true,
    rating: 4.8
  },
  
  // 💼 BUSINESS
  {
    title: 'Professional Business Suit',
    description: 'Tailored business suit in premium fabric. Perfect for meetings and formal events.',
    price: 399.99,
    category: 'Clothing',
    subCategory: 'Suits',
    styleType: 'Business',
    targetGender: 'M',
    targetAgeGroup: 'Adult',
    tags: ['professional', 'formal', 'business', 'elegant'],
    stock: 30,
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800',
    featured: true,
    rating: 4.9
  },
  {
    title: 'Executive Dress Shirt',
    description: 'Premium cotton dress shirt. Wrinkle-resistant, perfect for the office.',
    price: 89.99,
    category: 'Clothing',
    subCategory: 'Shirts',
    styleType: 'Business',
    targetGender: 'M',
    targetAgeGroup: 'Adult',
    tags: ['professional', 'office', 'elegant', 'formal'],
    stock: 60,
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800',
    rating: 4.6
  },
  {
    title: 'Luxury Leather Briefcase',
    description: 'Handcrafted leather briefcase for professionals. Timeless elegance.',
    price: 299.99,
    category: 'Accessories',
    subCategory: 'Bags',
    styleType: 'Business',
    targetGender: 'Unisex',
    targetAgeGroup: 'Adult',
    tags: ['professional', 'luxury', 'leather', 'business'],
    stock: 25,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800',
    rating: 4.7
  },
  
  // ⚽ SPORT
  {
    title: 'Pro Running Shoes',
    description: 'High-performance running shoes with advanced cushioning. Run faster, longer.',
    price: 129.99,
    category: 'Footwear',
    subCategory: 'Athletic',
    styleType: 'Sport',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['athletic', 'running', 'sport', 'fitness'],
    stock: 50,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
    featured: true,
    rating: 4.8
  },
  {
    title: 'Athletic Gym Shorts',
    description: 'Breathable athletic shorts with moisture-wicking technology. Perfect for workouts.',
    price: 39.99,
    category: 'Clothing',
    subCategory: 'Sportswear',
    styleType: 'Sport',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['athletic', 'gym', 'comfortable', 'sport'],
    stock: 120,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800',
    rating: 4.4
  },
  {
    title: 'Yoga Mat Premium',
    description: 'Extra-thick yoga mat with non-slip surface. Perfect for all exercises.',
    price: 49.99,
    category: 'Sports Equipment',
    subCategory: 'Yoga',
    styleType: 'Sport',
    targetGender: 'Unisex',
    targetAgeGroup: 'Adult',
    tags: ['fitness', 'yoga', 'sport', 'wellness'],
    stock: 75,
    image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=800',
    rating: 4.6
  },
  
  // 💻 TECH
  {
    title: 'Wireless Bluetooth Headphones',
    description: 'Premium noise-canceling headphones. Crystal clear sound, all-day battery.',
    price: 299.99,
    category: 'Electronics',
    subCategory: 'Audio',
    styleType: 'Tech',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['tech', 'audio', 'wireless', 'electronics'],
    stock: 40,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800',
    featured: true,
    rating: 4.7
  },
  {
    title: 'Smart Watch Fitness Tracker',
    description: 'Advanced smartwatch with health monitoring. Track your fitness goals.',
    price: 249.99,
    category: 'Electronics',
    subCategory: 'Wearables',
    styleType: 'Tech',
    targetGender: 'Unisex',
    targetAgeGroup: 'Adult',
    tags: ['tech', 'fitness', 'smart', 'wearable'],
    stock: 35,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800',
    rating: 4.5
  },
  {
    title: 'Wireless Gaming Mouse',
    description: 'Professional gaming mouse with RGB lighting. Precision and speed.',
    price: 79.99,
    category: 'Electronics',
    subCategory: 'Gaming',
    styleType: 'Tech',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['tech', 'gaming', 'wireless', 'rgb'],
    stock: 90,
    image: 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=800',
    rating: 4.6
  },
  
  // 💎 ELEGANT
  {
    title: 'Designer Leather Handbag',
    description: 'Luxury leather handbag from premium collection. Timeless elegance.',
    price: 599.99,
    category: 'Accessories',
    subCategory: 'Bags',
    styleType: 'Elegant',
    targetGender: 'F',
    targetAgeGroup: 'Adult',
    tags: ['luxury', 'elegant', 'designer', 'leather'],
    stock: 20,
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800',
    featured: true,
    rating: 4.9
  },
  {
    title: 'Silk Scarf Premium',
    description: 'Premium silk scarf with elegant patterns. Perfect accessory for any outfit.',
    price: 149.99,
    category: 'Accessories',
    subCategory: 'Scarves',
    styleType: 'Elegant',
    targetGender: 'F',
    targetAgeGroup: 'Senior',
    tags: ['luxury', 'silk', 'elegant', 'fashion'],
    stock: 45,
    image: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=800',
    rating: 4.7
  },
  {
    title: 'Gold Watch Luxury',
    description: 'Luxury gold watch with Swiss movement. Statement of elegance.',
    price: 899.99,
    category: 'Accessories',
    subCategory: 'Watches',
    styleType: 'Elegant',
    targetGender: 'Unisex',
    targetAgeGroup: 'Adult',
    tags: ['luxury', 'elegant', 'gold', 'premium'],
    stock: 15,
    image: 'https://images.unsplash.com/photo-1587836374228-4c9986a8e03f?w=800',
    rating: 4.8
  },
  
  // ✨ TRENDY
  {
    title: 'Trendy Sunglasses',
    description: 'Fashion-forward sunglasses with UV protection. Instagram-ready style.',
    price: 89.99,
    category: 'Accessories',
    subCategory: 'Eyewear',
    styleType: 'Trendy',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['trendy', 'fashion', 'sunglasses', 'style'],
    stock: 70,
    image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800',
    rating: 4.5
  },
  {
    title: 'Modern Backpack',
    description: 'Stylish and functional backpack for urban explorers. Trendy design.',
    price: 119.99,
    category: 'Accessories',
    subCategory: 'Bags',
    styleType: 'Trendy',
    targetGender: 'Unisex',
    targetAgeGroup: 'Young',
    tags: ['trendy', 'modern', 'backpack', 'urban'],
    stock: 55,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800',
    rating: 4.6
  }
];

/**
 * 🌱 Fonction principale de seed
 */
async function seed() {
  try {
    console.log('🔄 Connecting to MongoDB...');
    await mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ Connected to MongoDB');
    
    // 🗑️ Nettoyer les données existantes
    console.log('🗑️  Cleaning old data...');
    await Product.deleteMany({});
    await User.deleteMany({ 
      email: { $in: ['admin@test.com', 'user@test.com', 'demo@test.com'] } 
    });
    
    // 📦 Insérer les produits
    console.log('📦 Inserting products...');
    const products = await Product.insertMany(sampleProducts);
    console.log(`✅ Inserted ${products.length} products`);
    
    // 👤 Créer l'admin
    console.log('👤 Creating admin user...');
    const adminPassword = await bcrypt.hash('admin123', 10);
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@test.com',
      password: adminPassword,
      role: 'admin',
      age: 30,
      gender: 'M',
      points: 10000,
      styleId: 'Business-Adult-M',
      stylePreferences: {
        primary: 'Business',
        secondary: ['Tech', 'Elegant']
      }
    });
    console.log('✅ Admin created: admin@test.com / admin123');
    
    // 👤 Créer un utilisateur test
    console.log('👤 Creating test user...');
    const userPassword = await bcrypt.hash('user123', 10);
    const user = await User.create({
      name: 'Test User',
      email: 'user@test.com',
      password: userPassword,
      age: 25,
      gender: 'M',
      points: 1500,
      styleId: 'Casual-Young-M',
      stylePreferences: {
        primary: 'Casual',
        secondary: ['Sport', 'Tech']
      }
    });
    console.log('✅ User created: user@test.com / user123');
    
    // 👤 Créer un utilisateur demo
    console.log('👤 Creating demo user...');
    const demoPassword = await bcrypt.hash('demo123', 10);
    const demo = await User.create({
      name: 'Demo User',
      email: 'demo@test.com',
      password: demoPassword,
      age: 35,
      gender: 'F',
      points: 5000,
      styleId: 'Elegant-Adult-F',
      stylePreferences: {
        primary: 'Elegant',
        secondary: ['Trendy', 'Business']
      }
    });
    console.log('✅ Demo created: demo@test.com / demo123');
    
    // 📊 Afficher le résumé
    console.log('\n🎉 ================================');
    console.log('   SEED COMPLETED SUCCESSFULLY!');
    console.log('   ================================');
    console.log('\n📝 Login credentials:');
    console.log('   👨‍💼 Admin: admin@test.com / admin123');
    console.log('   👤 User:  user@test.com / user123');
    console.log('   🎭 Demo:  demo@test.com / demo123');
    console.log('\n📊 Database stats:');
    console.log(`   📦 Products: ${products.length}`);
    console.log(`   👥 Users: 3`);
    console.log('\n🚀 You can now start the server!');
    console.log('   Backend: npm run dev');
    console.log('   Frontend: npm run dev\n');
    
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
}

// 🚀 Lancer le seed
seed();