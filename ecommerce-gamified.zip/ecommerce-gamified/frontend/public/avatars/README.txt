Place your avatar image files here. Filenames are expected like Casual-Young-M.png etc.
