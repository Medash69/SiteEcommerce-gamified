import React, { createContext, useEffect, useState } from "react";

export const CartContext = createContext();

export function CartProvider({ children }) {
  const [cart, setCart] = useState(() => {
    try { return JSON.parse(localStorage.getItem("cart_v1")) || []; } catch { return []; }
  });

  useEffect(() => { localStorage.setItem("cart_v1", JSON.stringify(cart)); }, [cart]);

  const add = (product, qty = 1) => {
    setCart(prev => {
      const ex = prev.find(i => String(i._id) === String(product._id));
      if (ex) return prev.map(i => i._id === product._id ? { ...i, qty: i.qty + qty } : i);
      return [...prev, { ...product, qty }];
    });
  };

  const updateQty = (id, qty) => {
    setCart(prev => prev.map(i => i._id === id ? { ...i, qty } : i));
  };

  const remove = (id) => setCart(prev => prev.filter(i => i._id !== id));

  const clear = () => setCart([]);

  const subtotal = cart.reduce((s, i) => s + (i.price * (i.qty || 1)), 0);

  return (
    <CartContext.Provider value={{ cart, add, updateQty, remove, clear, subtotal }}>
      {children}
    </CartContext.Provider>
  );
}
