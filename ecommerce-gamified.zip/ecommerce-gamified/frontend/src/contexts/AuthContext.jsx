import React, { createContext, useEffect, useState } from "react";
import API from "../api";

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  const loadProfile = async () => {
    const token = localStorage.getItem("token");
    if (!token) { setReady(true); return; }
    try {
      const { data } = await API.get("/user/me");
      setUser(data);
    } catch (e) {
      console.error("loadProfile", e);
      localStorage.removeItem("token");
      setUser(null);
    } finally { setReady(true); }
  };

  useEffect(() => { loadProfile(); }, []);

  const refresh = async () => { await loadProfile(); };

  return (
    <AuthContext.Provider value={{ user, setUser, refresh, ready }}>
      {children}
    </AuthContext.Provider>
  );
}
