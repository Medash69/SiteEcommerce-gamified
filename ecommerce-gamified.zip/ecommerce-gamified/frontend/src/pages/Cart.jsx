import React, { useContext, useState } from "react";
import { CartContext } from "../contexts/CartContext";
import { AuthContext } from "../contexts/AuthContext";
import API from "../api";
import { determineBadge } from "../utils/badges";

export default function Cart() {
  const { cart, updateQty, remove, clear, subtotal } = useContext(CartContext);
  const { user, refresh } = useContext(AuthContext);
  const [loading, setLoading] = useState(false);

  const currentBadge = determineBadge(user?.points || 0);

  const getDiscountRate = () => {
    if (currentBadge.name.includes("Bronze")) return 0.02;
    if (currentBadge.name.includes("Silver")) return 0.05;
    if (currentBadge.name.includes("Gold")) return 0.08;
    if (currentBadge.name.includes("Platinum")) return 0.12;
    return 0;
  };

  const discountRate = getDiscountRate();
  const discount = subtotal * discountRate;
  const total = subtotal - discount;

  const checkout = async () => {
    if (cart.length === 0) return alert("Panier vide");
    setLoading(true);
    try {
      const earnedPoints = Math.floor(total / 10);
      await API.post("/user/earnpoints", { points: earnedPoints }).catch(() => {});
      await API.post("/user/checkout", { items: cart, total }).catch(() => {});
      clear();
      await refresh();
      alert(`Commande OK — vous avez gagné ${earnedPoints} points`);
    } catch (err) {
      console.error(err);
      alert("Erreur paiement (simulation)");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <h2 className="text-2xl font-bold mb-4">🛒 Mon Panier</h2>

      {cart.length === 0 ? (
        <div className="bg-white p-6 rounded shadow text-center text-gray-600">
          Ton panier est vide.
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {/* Liste des produits */}
          <div className="md:col-span-2 bg-white p-4 rounded shadow space-y-4">
            {cart.map((item) => (
              <div
                key={item._id}
                className="flex items-center justify-between border-b pb-3"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={item.image || "https://placehold.co/100x80"}
                    alt={item.title}
                    className="w-24 h-20 object-cover rounded"
                  />
                  <div>
                    <div className="font-semibold">{item.title}</div>
                    <div className="text-sm text-gray-500">{item.price.toFixed(2)} €</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    value={item.qty}
                    onChange={(e) =>
                      updateQty(item._id, Math.max(1, Number(e.target.value)))
                    }
                    className="w-20 p-1 border rounded text-center"
                  />
                  <span className="font-semibold">
                    {(item.price * item.qty).toFixed(2)} €
                  </span>
                  <button
                    onClick={() => remove(item._id)}
                    className="text-red-500 hover:underline"
                  >
                    Supprimer
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Récapitulatif */}
          <div className="bg-white p-4 rounded shadow flex flex-col gap-3">
            <h3 className="font-bold text-lg mb-2">Résumé</h3>
            <div className="flex justify-between">
              <span>Sous-total</span>
              <span>{subtotal.toFixed(2)} €</span>
            </div>
            <div className="flex justify-between">
              <span>Réduction ({currentBadge.name})</span>
              <span>-{discount.toFixed(2)} €</span>
            </div>
            <div className="mt-3 border-t pt-3 text-xl font-extrabold">
              Total: {total.toFixed(2)} €
            </div>

            <button
              disabled={loading}
              onClick={checkout}
              className="mt-4 w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700 transition-colors font-semibold"
            >
              {loading ? "Traitement..." : "Payer (simulation)"}
            </button>

            <p className="text-sm text-gray-500 mt-2">
              Vous gagnez 1 point par 10 € dépensés.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
