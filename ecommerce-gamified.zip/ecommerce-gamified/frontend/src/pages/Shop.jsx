import React, { useEffect, useState, useContext } from "react";
import API from "../api";
import ProductCard from "../components/ProductCard";
import { CartContext } from "../contexts/CartContext";
import LoadingSpinner from "../components/LoadingSpinner";

export default function Shop() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    q: "",
    category: "",
    min: "",
    max: "",
    sort: "new",
    styleType: ""
  });
  const [categories, setCategories] = useState([]);
  
  const { add } = useContext(CartContext);

  useEffect(() => {
    loadCategories();
    loadProducts();
  }, []);

  const loadCategories = async () => {
    try {
      const { data } = await API.get("/products/meta/categories");
      setCategories(data);
    } catch (err) {
      console.error(err);
    }
  };

  const loadProducts = async () => {
    setLoading(true);
    try {
      const params = Object.fromEntries(
        Object.entries(filters).filter(([_, v]) => v !== "")
      );
      const { data } = await API.get("/products", { params });
      setProducts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    loadProducts();
  };

  return (
    <div className="container py-5">
      <h2 className="mb-4 text-center text-primary fw-bold">🛍️ Shop All Products</h2>

      {/* Filters */}
      <form onSubmit={handleSearch} className="card p-3 mb-4 shadow-sm">
        <div className="row g-3">
          <div className="col-md-4">
            <input
              value={filters.q}
              onChange={(e) => handleFilterChange("q", e.target.value)}
              placeholder="Search products..."
              className="form-control"
            />
          </div>

          <div className="col-md-2">
            <select
              value={filters.category}
              onChange={(e) => handleFilterChange("category", e.target.value)}
              className="form-select"
            >
              <option value="">All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="col-md-2">
            <select
              value={filters.styleType}
              onChange={(e) => handleFilterChange("styleType", e.target.value)}
              className="form-select"
            >
              <option value="">All Styles</option>
              <option value="Casual">Casual</option>
              <option value="Business">Business</option>
              <option value="Sport">Sport</option>
              <option value="Tech">Tech</option>
              <option value="Elegant">Elegant</option>
              <option value="Trendy">Trendy</option>
            </select>
          </div>

          <div className="col-md-2">
            <select
              value={filters.sort}
              onChange={(e) => handleFilterChange("sort", e.target.value)}
              className="form-select"
            >
              <option value="new">Newest</option>
              <option value="popular">Popular</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
          </div>

          <div className="col-md-2 d-grid">
            <button type="submit" className="btn btn-primary fw-bold">
              Search
            </button>
          </div>

          <div className="col-md-1">
            <input
              type="number"
              value={filters.min}
              onChange={(e) => handleFilterChange("min", e.target.value)}
              placeholder="Min"
              className="form-control"
            />
          </div>
          <div className="col-md-1">
            <input
              type="number"
              value={filters.max}
              onChange={(e) => handleFilterChange("max", e.target.value)}
              placeholder="Max"
              className="form-control"
            />
          </div>
        </div>
      </form>

      {/* Products */}
      {loading ? (
        <div className="d-flex justify-content-center py-5">
          <LoadingSpinner />
        </div>
      ) : products.length === 0 ? (
        <div className="card p-5 text-center shadow-sm">
          <div className="display-1 mb-3">🔍</div>
          <h4 className="fw-bold mb-2">No products found</h4>
          <p className="text-muted">Try adjusting your filters</p>
        </div>
      ) : (
        <>
          <div className="mb-3 text-end text-muted">
            Found {products.length} product{products.length !== 1 ? 's' : ''}
          </div>
          <div className="row g-4">
            {products.map(p => (
              <div key={p._id} className="col-12 col-sm-6 col-lg-3">
                <ProductCard product={p} onAdd={add} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
