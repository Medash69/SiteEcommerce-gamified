import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api";
import { AuthContext } from "../contexts/AuthContext";

export default function Register() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    age: 25,
    gender: "M",
    referralCode: ""
  });
  const [loading, setLoading] = useState(false);
  const { refresh } = useContext(AuthContext);
  const nav = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { data } = await API.post("/auth/register", formData);
      localStorage.setItem("token", data.token);
      await refresh();
      alert("🎉 Welcome! You earned 100 points!");
      nav("/quiz");
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.msg || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="d-flex align-items-center justify-content-center min-vh-100 bg-light">
      <div className="card shadow-lg p-4 p-md-5" style={{ maxWidth: "450px", width: "100%" }}>
        <div className="text-center mb-4">
          <h2 className="fw-bold mb-2">Join GameShop!</h2>
          <p className="text-muted">Create account and start earning rewards</p>
        </div>

        <form onSubmit={submit}>
          <div className="mb-3">
            <label className="form-label fw-semibold">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Your Name"
              required
              className="form-control"
            />
          </div>

          <div className="mb-3">
            <label className="form-label fw-semibold">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="your@email.com"
              required
              className="form-control"
            />
          </div>

          <div className="mb-3">
            <label className="form-label fw-semibold">Password</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              required
              minLength="6"
              className="form-control"
            />
          </div>

          <div className="row g-3 mb-3">
            <div className="col">
              <label className="form-label fw-semibold">Age</label>
              <input
                type="number"
                name="age"
                value={formData.age}
                onChange={handleChange}
                min="18"
                max="100"
                className="form-control"
              />
            </div>
            <div className="col">
              <label className="form-label fw-semibold">Gender</label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="form-select"
              >
                <option value="M">Male</option>
                <option value="F">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label fw-semibold">Referral Code (Optional)</label>
            <input
              type="text"
              name="referralCode"
              value={formData.referralCode}
              onChange={handleChange}
              placeholder="Enter code to get bonus points"
              className="form-control"
            />
          </div>

          <div className="alert alert-success mb-3" role="alert">
            🎁 Sign up bonus: 100 points + Take quiz for 100 more!
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-success w-100 fw-bold"
          >
            {loading ? "Creating account..." : "Create Account"}
          </button>
        </form>

        <div className="mt-3 text-center">
          <p className="text-muted mb-0">
            Already have an account?{" "}
            <Link to="/login" className="text-success fw-semibold">
              Login here
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
