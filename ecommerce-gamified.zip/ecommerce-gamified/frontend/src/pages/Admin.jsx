import React, { useEffect, useState, useContext } from "react";
import API from "../api";
import { AuthContext } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import LoadingSpinner from "../components/LoadingSpinner";

export default function Admin() {
  const { user } = useContext(AuthContext);
  const nav = useNavigate();
  const [products, setProducts] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    title: "",
    price: "",
    category: "",
    subCategory: "",
    description: "",
    stock: "",
    styleType: "",
    targetGender: "",
    targetAgeGroup: "",
    tags: "",
    image: null
  });

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      alert("Admin access required");
      nav("/");
      return;
    }
    loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [productsRes, statsRes] = await Promise.all([
        API.get("/products"),
        API.get("/admin/stats")
      ]);
      setProducts(productsRes.data);
      setStats(statsRes.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    if (e.target.name === "image") {
      setForm({ ...form, image: e.target.files[0] });
    } else {
      setForm({ ...form, [e.target.name]: e.target.value });
    }
  };

  const addProduct = async (e) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      Object.keys(form).forEach(key => {
        if (form[key]) fd.append(key, form[key]);
      });

      await API.post("/products/admin/add", fd, {
        headers: { "Content-Type": "multipart/form-data" }
      });

      alert("✅ Product added successfully!");
      setForm({
        title: "",
        price: "",
        category: "",
        subCategory: "",
        description: "",
        stock: "",
        styleType: "",
        targetGender: "",
        targetAgeGroup: "",
        tags: "",
        image: null
      });
      await loadData();
    } catch (err) {
      console.error(err);
      alert("Error adding product");
    }
  };

  const deleteProduct = async (id) => {
    if (!confirm("Delete this product?")) return;
    try {
      await API.delete(`/admin/product/${id}`);
      alert("✅ Product deleted");
      await loadData();
    } catch (err) {
      console.error(err);
      alert("Error deleting product");
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">⚙️ Admin Dashboard</h2>

        {/* Stats Cards */}
        {stats && (
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-indigo-600">{stats.totalUsers}</div>
              <div className="text-gray-600 mt-1">Total Users</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-green-600">{stats.totalProducts}</div>
              <div className="text-gray-600 mt-1">Products</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-purple-600">{stats.totalOrders}</div>
              <div className="text-gray-600 mt-1">Orders</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-3xl font-bold text-orange-600">
                ${stats.totalRevenue?.toFixed(2)}
              </div>
              <div className="text-gray-600 mt-1">Revenue</div>
            </div>
          </div>
        )}

        {/* Add Product Form */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h3 className="text-xl font-bold mb-4">Add New Product</h3>
          <form onSubmit={addProduct} className="grid md:grid-cols-2 gap-4">
            <input
              name="title"
              value={form.title}
              onChange={handleChange}
              placeholder="Product Title *"
              required
              className="p-3 border rounded-lg"
            />
            <input
              name="price"
              type="number"
              step="0.01"
              value={form.price}
              onChange={handleChange}
              placeholder="Price *"
              required
              className="p-3 border rounded-lg"
            />
            <input
              name="category"
              value={form.category}
              onChange={handleChange}
              placeholder="Category *"
              required
              className="p-3 border rounded-lg"
            />
            <input
              name="subCategory"
              value={form.subCategory}
              onChange={handleChange}
              placeholder="Sub Category"
              className="p-3 border rounded-lg"
            />
            <select
              name="styleType"
              value={form.styleType}
              onChange={handleChange}
              className="p-3 border rounded-lg"
            >
              <option value="">Style Type</option>
              <option value="Casual">Casual</option>
              <option value="Business">Business</option>
              <option value="Sport">Sport</option>
              <option value="Tech">Tech</option>
              <option value="Elegant">Elegant</option>
              <option value="Trendy">Trendy</option>
            </select>
            <select
              name="targetGender"
              value={form.targetGender}
              onChange={handleChange}
              className="p-3 border rounded-lg"
            >
              <option value="">Target Gender</option>
              <option value="M">Male</option>
              <option value="F">Female</option>
              <option value="Unisex">Unisex</option>
            </select>
            <select
              name="targetAgeGroup"
              value={form.targetAgeGroup}
              onChange={handleChange}
              className="p-3 border rounded-lg"
            >
              <option value="">Target Age</option>
              <option value="Young">Young (18-25)</option>
              <option value="Adult">Adult (26-45)</option>
              <option value="Senior">Senior (46+)</option>
            </select>
            <input
              name="stock"
              type="number"
              value={form.stock}
              onChange={handleChange}
              placeholder="Stock Quantity"
              className="p-3 border rounded-lg"
            />
            <input
              name="tags"
              value={form.tags}
              onChange={handleChange}
              placeholder="Tags (comma separated)"
              className="p-3 border rounded-lg md:col-span-2"
            />
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              placeholder="Product Description"
              rows="3"
              className="p-3 border rounded-lg md:col-span-2"
            />
            <input
              name="image"
              type="file"
              accept="image/*"
              onChange={handleChange}
              className="p-3 border rounded-lg"
            />
            <button
              type="submit"
              className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 font-bold"
            >
              Add Product
            </button>
          </form>
        </div>

        {/* Products List */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-bold mb-4">All Products ({products.length})</h3>
          <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map(p => (
              <div key={p._id} className="border rounded-lg p-4">
                <img
                  src={p.image || "https://images.unsplash.com/photo-1523275335684-37898b6baf30"}
                  className="w-full h-40 object-cover rounded mb-3"
                  alt={p.title}
                />
                <h4 className="font-bold text-sm mb-1 line-clamp-2">{p.title}</h4>
                <div className="text-xs text-gray-600 mb-2">{p.category}</div>
                <div className="flex justify-between items-center">
                  <div className="font-bold text-indigo-600">${p.price}</div>
                  <button
                    onClick={() => deleteProduct(p._id)}
                    className="bg-red-500 text-white px-3 py-1 rounded text-xs hover:bg-red-600"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}