import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../api";
import { AuthContext } from "../contexts/AuthContext";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { refresh } = useContext(AuthContext);
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data } = await API.post("/auth/login", { email, password });
      localStorage.setItem("token", data.token);
      await refresh();
      nav("/");
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.msg || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-light min-vh-100 d-flex align-items-center justify-content-center py-5">
      <div className="card shadow-lg p-4 p-md-5" style={{ maxWidth: "400px", width: "100%" }}>
        <div className="text-center mb-4">
          <h2 className="fw-bold mb-2">Welcome Back!</h2>
          <p className="text-muted">Login to continue your gaming journey</p>
        </div>

        <form onSubmit={submit}>
          <div className="mb-3">
            <label className="form-label fw-semibold">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              required
              className="form-control"
            />
          </div>

          <div className="mb-3">
            <label className="form-label fw-semibold">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="form-control"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary w-100 fw-bold"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <div className="mt-3 text-center">
          <p className="text-muted mb-0">
            Don't have an account?{" "}
            <Link to="/register" className="text-primary fw-semibold">
              Sign up now
            </Link>
          </p>
        </div>

        <div className="mt-4 p-3 bg-info bg-opacity-10 rounded">
          <p className="fw-semibold text-info mb-1">Demo Accounts:</p>
          <p className="mb-0 text-info small">Admin: admin@test.com / admin123</p>
          <p className="mb-0 text-info small">User: user@test.com / user123</p>
        </div>
      </div>
    </div>
  );
}
