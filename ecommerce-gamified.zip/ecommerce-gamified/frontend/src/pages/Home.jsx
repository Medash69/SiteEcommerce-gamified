import React, { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../contexts/AuthContext";
import { determineBadge, getNextBadge } from "../utils/badges";
import BadgePill from "../components/BadgePill";
import BadgeProgress from "../components/BadgeProgress";
import API from "../api";
import ProductCard from "../components/ProductCard";
import { CartContext } from "../contexts/CartContext";

export default function Home() {
  const { user } = useContext(AuthContext);
  const { add } = useContext(CartContext);
  const [featured, setFeatured] = useState([]);
  const [recommendations, setRecommendations] = useState([]);

  const badge = user ? determineBadge(user.points || 0) : null;
  const nextBadge = user ? getNextBadge(user.points || 0) : null;

  useEffect(() => {
    loadFeatured();
    if (user) loadRecommendations();
  }, [user]);

  const loadFeatured = async () => {
    try {
      const { data } = await API.get("/products/featured/list");
      setFeatured(data.slice(0, 4));
    } catch (err) {
      console.error(err);
    }
  };

  const loadRecommendations = async () => {
    try {
      const { data } = await API.get("/user/recommendations");
      setRecommendations(data.slice(0, 4));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="bg-light min-vh-100">
      {/* Hero Section */}
      <div className="bg-primary text-white py-5 text-center">
        <div className="container">
          <h1 className="display-4 fw-bold">Welcome to GameShop 🎮</h1>
          <p className="lead mb-4">Shop, Earn Points, Unlock Badges & Get Rewards!</p>

          {user ? (
            <div className="d-flex flex-column align-items-center gap-3">
              <div className="d-flex align-items-center gap-4 bg-white bg-opacity-25 p-3 rounded-3">
                <div className="text-center">
                  <h3 className="fw-bold">{user.points || 0}</h3>
                  <small>Points</small>
                </div>
                <div className="vr" style={{ height: "50px" }}></div>
                <div>
                  <BadgePill badge={badge} showReward={false} />
                </div>
              </div>
              {!user.styleId && (
                <Link to="/quiz" className="btn btn-warning btn-lg fw-bold">
                  Take Quiz & Get 100 Points! 🎁
                </Link>
              )}
            </div>
          ) : (
            <Link to="/register" className="btn btn-warning btn-lg fw-bold">
              Get Started - Earn 100 Points!
            </Link>
          )}
        </div>
      </div>

      <div className="container py-5">
        {/* User Progress */}
        {user && badge && (
          <div className="row mb-5">
            <div className="col-md-6 mb-4">
              <div className="card shadow-sm h-100">
                <div className="card-body">
                  <h5 className="card-title fw-bold">Your Progress</h5>
                  <BadgeProgress 
                    current={badge}
                    next={nextBadge}
                    progress={nextBadge ? ((user.points - badge.minPoints) / (nextBadge.minPoints - badge.minPoints)) * 100 : 100}
                    pointsNeeded={nextBadge ? nextBadge.minPoints - user.points : 0}
                  />
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <div className="card shadow-sm h-100 bg-light">
                <div className="card-body">
                  <h5 className="card-title text-success fw-bold">Ways to Earn Points</h5>
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item d-flex justify-content-between">💬 Leave a comment <span className="fw-bold">+50</span></li>
                    <li className="list-group-item d-flex justify-content-between">🎯 Complete quiz <span className="fw-bold">+100</span></li>
                    <li className="list-group-item d-flex justify-content-between">👥 Refer a friend <span className="fw-bold">+200</span></li>
                    <li className="list-group-item d-flex justify-content-between">🛍️ Make a purchase <span className="fw-bold">1pt / $10</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Recommendations */}
        {user && recommendations.length > 0 && (
          <div className="mb-5">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h2 className="fw-bold">✨ Recommended For You</h2>
              <Link to="/shop" className="text-decoration-none text-primary">View All →</Link>
            </div>
            <div className="row g-3">
              {recommendations.map(p => (
                <div className="col-12 col-sm-6 col-lg-3" key={p._id}>
                  <ProductCard product={p} onAdd={add} showScore={true} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Featured Products */}
        <div className="mb-5">
          <h2 className="fw-bold mb-3">⭐ Featured Products</h2>
          <div className="row g-3">
            {featured.map(p => (
              <div className="col-12 col-sm-6 col-lg-3" key={p._id}>
                <ProductCard product={p} onAdd={add} />
              </div>
            ))}
          </div>
        </div>

        {/* Features Grid */}
        <div className="row g-3">
          <div className="col-md-4">
            <div className="card shadow-sm text-center h-100 p-3">
              <div className="display-4 mb-2">🎯</div>
              <h5 className="fw-bold">Personalized Shopping</h5>
              <p className="text-muted small">AI-powered recommendations based on your style</p>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card shadow-sm text-center h-100 p-3">
              <div className="display-4 mb-2">🏆</div>
              <h5 className="fw-bold">Earn Rewards</h5>
              <p className="text-muted small">Level up and unlock exclusive benefits</p>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card shadow-sm text-center h-100 p-3">
              <div className="display-4 mb-2">💎</div>
              <h5 className="fw-bold">VIP Access</h5>
              <p className="text-muted small">Reach legendary status for premium perks</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
