import React, { useContext, useState } from "react";
import { AuthContext } from "../contexts/AuthContext";
import API from "../api";
import Avatar from "../components/Avatar";
import { determineBadge } from "../utils/badges";
import BadgePill from "../components/BadgePill";

export default function Profile() {
  const { user, refresh } = useContext(AuthContext);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  if (!user) {
    return (
      <div className="p-6 text-center text-gray-700">
        Connecte-toi pour voir ton profil
      </div>
    );
  }

  const badge = determineBadge(user.points || 0);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) return alert("Choisir une image");
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("avatar", file);
      await API.post("/user/avatar", fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      await refresh();
      alert("Avatar mis à jour !");
      setFile(null);
    } catch (err) {
      console.error(err);
      alert("Erreur lors du téléversement");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Profil utilisateur */}
      <div className="bg-white rounded-lg shadow p-6 flex flex-col md:flex-row items-center gap-6">
        <Avatar styleId={user.styleId} size={96} />
        <div className="flex-1">
          <h2 className="text-2xl font-bold">{user.name || "Utilisateur"}</h2>
          <p className="text-gray-600">Email: {user.email}</p>
          <p className="mt-2">
            Points: <strong>{user.points}</strong>
          </p>
          <div className="mt-2">
            <BadgePill badge={badge} />
          </div>
        </div>
      </div>

      {/* Changer avatar */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-3">Changer mon avatar</h3>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <input
            type="file"
            onChange={handleFileChange}
            accept="image/*"
            className="form-control"
          />
          <button
            onClick={handleUpload}
            className="btn btn-success"
            disabled={uploading}
          >
            {uploading ? "Téléversement..." : "Téléverser"}
          </button>
        </div>
      </div>

      {/* Historique et badges */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-2">Historique & Badges</h3>
        <p className="text-gray-600 text-sm">
          Tes badges et récompenses sont attribués automatiquement selon tes
          points accumulés.
        </p>
        {/* Ici tu peux ajouter un composant pour afficher la liste des badges */}
      </div>
    </div>
  );
}
