// ==================== frontend/src/pages/Auth.jsx ====================
/**
 * 🔐 PAGE D'AUTHENTIFICATION (VERSION LEGACY)
 * 
 * Cette page combine Login et Register dans une seule interface
 * avec un toggle pour basculer entre les deux modes
 * 
 * NOTE: Cette version est conservée pour compatibilité
 * Les pages Login.jsx et Register.jsx séparées sont recommandées
 */

import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api';
import { AuthContext } from '../contexts/AuthContext';

export default function Auth() {
  const [mode, setMode] = useState('login'); // 'login' ou 'register'
  const [loading, setLoading] = useState(false);
  const { refresh } = useContext(AuthContext);
  const nav = useNavigate();
  
  // États du formulaire
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    age: 25,
    gender: 'M',
    referralCode: ''
  });

  // Gestion du changement des inputs
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // 🔐 Soumission du formulaire
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (mode === 'register') {
        // 📝 INSCRIPTION
        const { data } = await API.post('/auth/register', {
          name: formData.name,
          email: formData.email,
          password: formData.password,
          age: formData.age,
          gender: formData.gender,
          referralCode: formData.referralCode
        });
        
        localStorage.setItem('token', data.token);
        await refresh();
        
        alert('🎉 Inscription réussie ! Vous avez gagné 100 points !');
        nav('/quiz'); // Rediriger vers le quiz
      } else {
        // 🔓 CONNEXION
        const { data } = await API.post('/auth/login', {
          email: formData.email,
          password: formData.password
        });
        
        localStorage.setItem('token', data.token);
        await refresh();
        
        alert('✅ Connexion réussie !');
        nav('/'); // Rediriger vers l'accueil
      }
    } catch (err) {
      console.error('Auth error:', err);
      const errorMsg = err.response?.data?.msg || 'Erreur lors de l\'authentification';
      alert('❌ ' + errorMsg);
    } finally {
      setLoading(false);
    }
  };

  // 🔄 Basculer entre login et register
  const toggleMode = () => {
    setMode(mode === 'login' ? 'register' : 'login');
    // Réinitialiser le formulaire
    setFormData({
      name: '',
      email: '',
      password: '',
      age: 25,
      gender: 'M',
      referralCode: ''
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full">
        {/* 🎮 En-tête */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🎮</div>
          <h2 className="text-4xl font-bold text-gray-900 mb-2">
            {mode === 'register' ? 'Créer un Compte' : 'Bienvenue !'}
          </h2>
          <p className="text-gray-600">
            {mode === 'register' 
              ? 'Rejoignez GameShop et commencez à gagner des récompenses' 
              : 'Connectez-vous pour continuer votre aventure'}
          </p>
        </div>

        {/* 📝 Formulaire */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Nom (uniquement en register) */}
            {mode === 'register' && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Nom complet
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="John Doe"
                  required
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                />
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="votre@email.com"
                required
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
              />
            </div>

            {/* Mot de passe */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Mot de passe
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="••••••••"
                required
                minLength="6"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
              />
            </div>

            {/* Champs supplémentaires en register */}
            {mode === 'register' && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  {/* Âge */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Âge
                    </label>
                    <input
                      type="number"
                      name="age"
                      value={formData.age}
                      onChange={handleChange}
                      min="18"
                      max="100"
                      className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                    />
                  </div>

                  {/* Genre */}
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Genre
                    </label>
                    <select
                      name="gender"
                      value={formData.gender}
                      onChange={handleChange}
                      className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                    >
                      <option value="M">👨 Homme</option>
                      <option value="F">👩 Femme</option>
                      <option value="Other">🌈 Autre</option>
                    </select>
                  </div>
                </div>

                {/* Code de parrainage */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Code de parrainage (optionnel)
                  </label>
                  <input
                    type="text"
                    name="referralCode"
                    value={formData.referralCode}
                    onChange={handleChange}
                    placeholder="ABC123"
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                  />
                </div>

                {/* Bonus d'inscription */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border-2 border-green-200">
                  <p className="text-sm text-green-800 font-semibold flex items-center gap-2">
                    <span className="text-2xl">🎁</span>
                    <span>Bonus d'inscription : 100 points + Quiz = 200 points !</span>
                  </p>
                </div>
              </>
            )}

            {/* Bouton de soumission */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-lg hover:from-indigo-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 font-bold text-lg transition-all shadow-lg hover:shadow-xl disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Chargement...
                </span>
              ) : (
                mode === 'register' ? '🚀 Créer mon compte' : '🔓 Se connecter'
              )}
            </button>
          </form>

          {/* 🔄 Toggle entre login et register */}
          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {mode === 'register' 
                ? 'Vous avez déjà un compte ?' 
                : 'Vous n\'avez pas de compte ?'}
            </p>
            <button
              onClick={toggleMode}
              className="mt-2 text-indigo-600 hover:text-indigo-800 font-semibold text-lg transition"
            >
              {mode === 'register' ? '🔓 Se connecter' : '📝 Créer un compte'}
            </button>
          </div>

          {/* 📋 Comptes de test */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
            <p className="text-sm text-blue-800 font-semibold mb-2">
              💡 Comptes de test :
            </p>
            <div className="text-xs text-blue-700 space-y-1">
              <p>👨‍💼 Admin: admin@test.com / admin123</p>
              <p>👤 User: user@test.com / user123</p>
              <p>🎭 Demo: demo@test.com / demo123</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 text-center text-sm text-gray-500">
          <p>En vous inscrivant, vous acceptez nos conditions d'utilisation</p>
        </div>
      </div>
    </div>
  );
}