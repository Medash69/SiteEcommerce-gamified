import React, { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import API from "../api";
import { CartContext } from "../contexts/CartContext";

export default function Product(){
  const { id } = useParams();
  const [p, setP] = useState(null);
  const [text, setText] = useState("");
  const { add } = useContext(CartContext);

  const load = async () => {
    const r = await API.get("/products/" + id);
    setP(r.data);
  };

  useEffect(()=> { load(); }, [id]);

  const postComment = async () => {
    if (!text) return alert("Écris un commentaire");
    // username = from token profile or anonymous
    const name = (await (await API.get("/user/me").catch(()=>({data:{name:"Invité"}}))).data).name || "Invité";
    await API.post(`/products/${id}/comment`, { user: name, text });
    setText("");
    load();
  };

  if (!p) return <div className="p-6">Chargement...</div>;

  return (
    <div className="p-6">
      <div className="grid md:grid-cols-3 gap-6">
        <div className="col-span-1">
          <img src={p.image || "https://placehold.co/600x400"} className="w-full rounded" />
        </div>
        <div className="col-span-2">
          <h2 className="text-2xl font-bold">{p.title}</h2>
          <p className="text-gray-600 mt-2">{p.description}</p>
          <div className="mt-4 flex items-center justify-between">
            <div className="text-2xl font-extrabold">{p.price} €</div>
            <div className="flex gap-3">
              <button onClick={()=> add(p,1)} className="bg-green-600 text-white px-4 py-2 rounded">Ajouter au panier</button>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="font-bold">Commentaires</h3>
            <div className="mt-3 space-y-3">
              {p.comments && p.comments.length > 0 ? p.comments.map((c,i)=>(
                <div key={i} className="p-3 bg-gray-50 rounded">
                  <div className="font-semibold">{c.user}</div>
                  <div className="text-sm text-gray-700">{c.text}</div>
                </div>
              )) : <div className="text-gray-500">Aucun commentaire</div>}
            </div>

            <div className="mt-4">
              <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Laisser un commentaire..." className="w-full p-2 border rounded"></textarea>
              <button onClick={postComment} className="mt-2 bg-blue-600 text-white px-4 py-2 rounded">Poster</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
