import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api';
import { AuthContext } from '../contexts/AuthContext';

export default function Quiz() {
  const [step, setStep] = useState(1);
  const [data, setData] = useState({
    age: 25,
    gender: 'M',
    styles: [],
    interests: []
  });
  const { refresh } = useContext(AuthContext);
  const nav = useNavigate();

  const styleOptions = ['Casual', 'Business', 'Sport', 'Tech', 'Elegant', 'Trendy'];
  const interestOptions = [
    'Gaming', 'Fashion', 'Fitness', 'Technology', 'Travel', 'Music',
    'Reading', 'Cooking', 'Photography', 'Art'
  ];

  const toggleArrayItem = (key, value) => {
    setData(prev => ({
      ...prev,
      [key]: prev[key].includes(value)
        ? prev[key].filter(i => i !== value)
        : [...prev[key], value]
    }));
  };

  const handleSubmit = async () => {
    try {
      await API.post('/user/quiz', data);
      await refresh();
      alert('🎉 Quiz completed! You earned 100 points!');
      nav('/profile');
    } catch (err) {
      console.error(err);
      alert('Error submitting quiz');
    }
  };

  return (
    <div className="min-vh-100 bg-light py-5">
      <div className="container">
        <div className="card shadow-sm">
          <div className="card-body">
            <h2 className="card-title text-center mb-3">Style Profile Quiz 🎯</h2>
            <p className="text-center text-muted mb-4">Help us personalize your experience</p>

            {/* Progress bar */}
            <div className="progress mb-4" style={{ height: '10px' }}>
              <div
                className="progress-bar bg-primary"
                role="progressbar"
                style={{ width: `${(step / 4) * 100}%` }}
              ></div>
            </div>
            <p className="text-center mb-4">{step}/4 Completed</p>

            {/* Step 1: Basic Info */}
            {step === 1 && (
              <div>
                <h5>Basic Information</h5>
                <div className="mb-3">
                  <label className="form-label">Age: {data.age}</label>
                  <input
                    type="range"
                    min="18"
                    max="80"
                    value={data.age}
                    onChange={(e) => setData({ ...data, age: Number(e.target.value) })}
                    className="form-range"
                  />
                </div>
                <div>
                  <label className="form-label">Gender</label>
                  <div className="btn-group" role="group">
                    {['M', 'F', 'Other'].map(g => (
                      <button
                        key={g}
                        type="button"
                        onClick={() => setData({ ...data, gender: g })}
                        className={`btn ${data.gender === g ? 'btn-primary' : 'btn-outline-secondary'}`}
                      >
                        {g === 'M' ? '👨 Male' : g === 'F' ? '👩 Female' : '🌈 Other'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Styles */}
            {step === 2 && (
              <div>
                <h5>Style Preferences</h5>
                <p className="text-muted mb-2">Select all that apply</p>
                <div className="d-flex flex-wrap gap-2">
                  {styleOptions.map(style => (
                    <button
                      key={style}
                      type="button"
                      onClick={() => toggleArrayItem('styles', style)}
                      className={`btn ${data.styles.includes(style) ? 'btn-primary' : 'btn-outline-secondary'}`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 3: Interests */}
            {step === 3 && (
              <div>
                <h5>Interests</h5>
                <p className="text-muted mb-2">Select all that apply</p>
                <div className="d-flex flex-wrap gap-2">
                  {interestOptions.map(interest => (
                    <button
                      key={interest}
                      type="button"
                      onClick={() => toggleArrayItem('interests', interest)}
                      className={`btn ${data.interests.includes(interest) ? 'btn-primary btn-sm' : 'btn-outline-secondary btn-sm'}`}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 4: Review */}
            {step === 4 && (
              <div>
                <h5>Review Your Profile</h5>
                <ul className="list-group mb-3">
                  <li className="list-group-item"><strong>Age:</strong> {data.age}</li>
                  <li className="list-group-item"><strong>Gender:</strong> {data.gender}</li>
                  <li className="list-group-item"><strong>Styles:</strong> {data.styles.join(', ') || 'None selected'}</li>
                  <li className="list-group-item"><strong>Interests:</strong> {data.interests.join(', ') || 'None selected'}</li>
                </ul>
                <div className="alert alert-success">
                  🎁 Complete this quiz to earn 100 points!
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="d-flex justify-content-between mt-4">
              {step > 1 ? (
                <button
                  type="button"
                  className="btn btn-outline-secondary"
                  onClick={() => setStep(step - 1)}
                >
                  Back
                </button>
              ) : <div></div>}
              
              {step < 4 ? (
                <button
                  type="button"
                  className="btn btn-primary ms-auto"
                  onClick={() => setStep(step + 1)}
                >
                  Next
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn-success ms-auto"
                  onClick={handleSubmit}
                >
                  Complete Quiz & Earn Points!
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
