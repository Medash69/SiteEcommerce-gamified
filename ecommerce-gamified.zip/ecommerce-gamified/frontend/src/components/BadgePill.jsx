import React from "react";

// Couleurs des badges
const BADGE_COLORS = {
  Iron: 'from-gray-500 to-gray-600',
  Bronze: 'from-amber-600 to-amber-700',
  Silver: 'from-gray-300 to-gray-400',
  Gold: 'from-yellow-400 to-yellow-500',
  Platinum: 'from-slate-300 to-slate-400',
  Diamond: 'from-cyan-400 to-blue-500',
  Legendary: 'from-purple-500 to-pink-500'
};

// Logos / icônes personnalisés pour chaque badge
const BADGE_ICONS = {
  Iron: '⛓️',
  Bronze: '🥉',
  Silver: '🥈',
  Gold: '🥇',
  Platinum: '💎',
  Diamond: '💠',
  Legendary: '🌟'
};

export default function BadgePill({ badge, showReward = true }) {
  if (!badge) return null;

  const gradient = BADGE_COLORS[badge.tier] || 'from-gray-400 to-gray-500';
  const icon = BADGE_ICONS[badge.tier] || '🏆';

  return (
    <div className={`inline-flex items-center gap-2 bg-gradient-to-r ${gradient} text-white px-4 py-2 rounded-full text-sm shadow-lg hover:shadow-xl transition-all`}>
      <span className="text-lg">{icon}</span>
      <div className="flex flex-col">
        <strong className="text-sm">{badge.name}</strong>
        {showReward && badge.reward && (
          <span className="text-xs opacity-90">{badge.reward}</span>
        )}
      </div>
    </div>
  );
}
