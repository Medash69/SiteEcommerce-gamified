import React from "react";
import { Link } from "react-router-dom";

export default function ProductCard({ product, onAdd, showScore = false }) {
  return (
    <div className="bg-white rounded-lg shadow hover:shadow-xl transition-all duration-300 overflow-hidden group">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={product.image || "https://images.unsplash.com/photo-1523275335684-37898b6baf30"} 
          alt={product.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        {product.featured && (
          <div className="absolute top-2 right-2 bg-yellow-400 text-xs font-bold px-2 py-1 rounded-full">
            ⭐ Featured
          </div>
        )}
        {showScore && product.relevanceScore && (
          <div className="absolute top-2 left-2 bg-indigo-600 text-white text-xs font-bold px-2 py-1 rounded-full">
            {Math.round(product.relevanceScore)}% Match
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-gray-800 line-clamp-2">{product.title}</h3>
        </div>
        
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">{product.category}</span>
          {product.styleType && (
            <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded">{product.styleType}</span>
          )}
        </div>
        
        {product.rating > 0 && (
          <div className="flex items-center gap-1 mb-2">
            <span className="text-yellow-500">⭐</span>
            <span className="text-sm text-gray-600">{product.rating.toFixed(1)}</span>
          </div>
        )}
        
        <div className="flex items-center justify-between mt-4">
          <div className="text-xl font-bold text-indigo-600">${product.price.toFixed(2)}</div>
          <div className="flex gap-2">
            <button 
              onClick={() => onAdd(product)} 
              className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-sm transition-colors"
            >
              Add to Cart
            </button>
            <Link 
              to={`/product/${product._id}`} 
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg text-sm transition-colors"
            >
              View
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
