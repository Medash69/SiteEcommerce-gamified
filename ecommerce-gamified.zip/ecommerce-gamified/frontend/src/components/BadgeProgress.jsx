import React from "react";

export default function BadgeProgress({ current, next, progress, pointsNeeded }) {
  if (!current) return null;
  
  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold text-gray-700">Current Badge</span>
        <span className="text-sm text-gray-500">{current.name}</span>
      </div>
      
      {next ? (
        <>
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-xs text-gray-600">
            <span>{Math.round(progress)}% to {next.name}</span>
            <span>{pointsNeeded} points needed</span>
          </div>
        </>
      ) : (
        <div className="text-center py-2">
          <span className="text-sm font-bold text-purple-600">🎉 MAX LEVEL REACHED! 🎉</span>
        </div>
      )}
    </div>
  );
}
