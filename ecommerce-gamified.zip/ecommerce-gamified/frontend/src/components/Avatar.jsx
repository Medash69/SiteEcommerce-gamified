import React from "react";

const AVATARS = {
  // Casual Styles
  'Casual-Young-M': { icon: '👦', color: 'bg-blue-100', emoji: '🎮' },
  'Casual-Young-F': { icon: '👧', color: 'bg-pink-100', emoji: '🎀' },
  'Casual-Adult-M': { icon: '👨', color: 'bg-blue-200', emoji: '☕' },
  'Casual-Adult-F': { icon: '👩', color: 'bg-pink-200', emoji: '📱' },
  'Casual-Senior-M': { icon: '👴', color: 'bg-gray-200', emoji: '📰' },
  'Casual-Senior-F': { icon: '👵', color: 'bg-gray-200', emoji: '🌻' },
  
  // Business Styles
  'Business-Adult-M': { icon: '👔', color: 'bg-slate-100', emoji: '💼' },
  'Business-Adult-F': { icon: '👩‍💼', color: 'bg-purple-100', emoji: '💼' },
  'Business-Senior-M': { icon: '🧑‍💼', color: 'bg-slate-200', emoji: '📊' },
  'Business-Senior-F': { icon: '👩‍💼', color: 'bg-purple-200', emoji: '📈' },
  
  // Sport Styles
  'Sport-Young-M': { icon: '🏃‍♂️', color: 'bg-green-100', emoji: '⚽' },
  'Sport-Young-F': { icon: '🏃‍♀️', color: 'bg-green-100', emoji: '🎾' },
  'Sport-Adult-M': { icon: '🤸‍♂️', color: 'bg-green-200', emoji: '🏋️' },
  'Sport-Adult-F': { icon: '🤸‍♀️', color: 'bg-green-200', emoji: '🧘' },
  
  // Tech Styles
  'Tech-Young-M': { icon: '👨‍💻', color: 'bg-indigo-100', emoji: '💻' },
  'Tech-Young-F': { icon: '👩‍💻', color: 'bg-indigo-100', emoji: '⌨️' },
  'Tech-Adult-M': { icon: '🤖', color: 'bg-gray-100', emoji: '🖥️' },
  'Tech-Adult-F': { icon: '👩‍🔬', color: 'bg-purple-100', emoji: '🔬' },
  
  // Elegant Styles
  'Elegant-Adult-F': { icon: '👸', color: 'bg-rose-100', emoji: '💎' },
  'Elegant-Adult-M': { icon: '🤵', color: 'bg-amber-100', emoji: '🎩' },
  'Elegant-Senior-F': { icon: '👑', color: 'bg-rose-200', emoji: '💍' },
  
  // Trendy Styles
  'Trendy-Young-F': { icon: '💃', color: 'bg-fuchsia-100', emoji: '✨' },
  'Trendy-Young-M': { icon: '🕺', color: 'bg-cyan-100', emoji: '🎨' },
  
  Default: { icon: '👤', color: 'bg-yellow-100', emoji: '🌟' }
};

export default function Avatar({ styleId, size = 72, showBadge = false }) {
  const key = styleId || "Default";
  const data = AVATARS[key] || AVATARS.Default;
  
  return (
    <div className="relative inline-block">
      <div 
        style={{ width: size, height: size }} 
        className={`rounded-full flex items-center justify-center text-3xl ${data.color} border-2 border-white shadow-lg transition-transform hover:scale-105`}
      >
        {data.icon}
      </div>
      {showBadge && (
        <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow border-2 border-gray-100">
          <span className="text-lg">{data.emoji}</span>
        </div>
      )}
    </div>
  );
}
