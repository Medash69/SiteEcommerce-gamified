import React, { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../contexts/AuthContext";
import { CartContext } from "../contexts/CartContext";

export default function Navbar() {
  const { user, setUser } = useContext(AuthContext);
  const { cart } = useContext(CartContext);
  const nav = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
    nav("/login");
  };

  const cartCount = cart.reduce((sum, item) => sum + (item.qty || 1), 0);

  return (
    <nav className="bg-gradient-to-r from-indigo-700 to-purple-700 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">

          {/* Logo */}
          <Link to="/" className="text-2xl font-bold flex items-center gap-2">
            <span>🎮</span>
            <span>GameShop</span>
          </Link>

          {/* Navigation Links */}
          <div className="flex items-center gap-6">

            <Link 
              to="/shop" 
              className="hover:text-yellow-300 transition-colors"
            >
              🛍️ Shop
            </Link>

            {user?.role === "admin" && (
              <Link 
                to="/admin" 
                className="hover:text-yellow-300 transition-colors"
              >
                ⚙️ Admin
              </Link>
            )}

            <Link 
              to="/cart" 
              className="relative hover:text-yellow-300 transition-colors"
            >
              🛒 Cart
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-yellow-400 text-black text-xs font-bold px-2 py-1 rounded-full">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* User / Auth Buttons */}
            {user ? (
              <>
                <Link 
                  to="/profile" 
                  className="flex items-center gap-2 hover:text-yellow-300 transition-colors"
                >
                  <span>👤</span>
                  <span className="hidden md:inline">{user.name}</span>
                  <span className="bg-yellow-400 text-black text-xs font-bold px-2 py-1 rounded-full">
                    {user.points || 0}
                  </span>
                </Link>
                <button 
                  onClick={logout} 
                  className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="hover:text-yellow-300 transition-colors"
                >
                  Login
                </Link>
                <Link 
                  to="/register" 
                  className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg transition-colors"
                >
                  Sign Up
                </Link>
              </>
            )}

          </div>
        </div>
      </div>
    </nav>
  );
}
