import React from "react";

export default function LoadingSpinner({ size = "medium", color = "indigo" }) {
  // Définition des tailles
  const sizeClass = {
    small: "w-6 h-6",
    medium: "w-12 h-12",
    large: "w-16 h-16",
  }[size];

  // Classes de couleur dynamiques
  const borderColor = `border-${color}-200`;
  const borderTopColor = `border-t-${color}-600`;

  return (
    <div className="flex justify-center items-center p-8">
      <div
        className={`${sizeClass} border-4 ${borderColor} ${borderTopColor} rounded-full animate-spin`}
      />
    </div>
  );
}
