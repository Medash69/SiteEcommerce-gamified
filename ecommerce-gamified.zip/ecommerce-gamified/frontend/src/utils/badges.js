// Badge tier definitions (matching backend)
export const BADGE_TIERS = [
  { name: "Iron 1", tier: "Iron", minPoints: 0, reward: "None", color: "#78716c" },
  { name: "Iron 2", tier: "Iron", minPoints: 200, reward: "None", color: "#78716c" },
  { name: "Iron 3", tier: "Iron", minPoints: 500, reward: "None", color: "#78716c" },
  { name: "Bronze 1", tier: "Bronze", minPoints: 1000, reward: "50% Shipping", color: "#cd7f32" },
  { name: "Bronze 3", tier: "Bronze", minPoints: 2000, reward: "90% Shipping", color: "#cd7f32" },
  { name: "Silver 1", tier: "Silver", minPoints: 3000, reward: "5% Discount", color: "#c0c0c0" },
  { name: "Gold 1", tier: "Gold", minPoints: 7000, reward: "5% + Free Shipping", color: "#ffd700" },
  { name: "Gold 3", tier: "Gold", minPoints: 12000, reward: "10% + Free Shipping", color: "#ffd700" },
  { name: "Platinum 1", tier: "Platinum", minPoints: 20000, reward: "Free Product ($100)", color: "#e5e4e2" },
  { name: "Platinum 3", tier: "Platinum", minPoints: 35000, reward: "Free Product ($200)", color: "#e5e4e2" },
  { name: "Diamond", tier: "Diamond", minPoints: 50000, reward: "3 Gifts ($500)", color: "#b9f2ff" },
  { name: "Legendary", tier: "Legendary", minPoints: 100000, reward: "VIP Access", color: "#ff6b6b" }
];

/**
 * Determine current badge based on points
 */
export function determineBadge(points) {
  let current = BADGE_TIERS[0];
  
  for (const badge of BADGE_TIERS) {
    if (points >= badge.minPoints) {
      current = badge;
    } else {
      break;
    }
  }
  
  return current;
}

/**
 * Get next badge to unlock
 */
export function getNextBadge(points) {
  for (const badge of BADGE_TIERS) {
    if (points < badge.minPoints) {
      return badge;
    }
  }
  return null; // Max level reached
}

/**
 * Calculate progress to next badge (0-100)
 */
export function getBadgeProgress(points) {
  const current = determineBadge(points);
  const next = getNextBadge(points);
  
  if (!next) {
    return 100; // Max level
  }
  
  const pointsInCurrentTier = points - current.minPoints;
  const pointsNeededForNext = next.minPoints - current.minPoints;
  const progress = (pointsInCurrentTier / pointsNeededForNext) * 100;
  
  return Math.min(Math.max(progress, 0), 100);
}

/**
 * Get discount rate based on badge
 */
export function getDiscountRate(badge) {
  if (!badge) return 0;
  
  if (badge.name.includes("Bronze")) return 0.02;
  if (badge.name.includes("Silver")) return 0.05;
  if (badge.name.includes("Gold")) return 0.08;
  if (badge.name.includes("Platinum")) return 0.12;
  if (badge.name.includes("Diamond")) return 0.15;
  if (badge.name.includes("Legendary")) return 0.20;
  
  return 0;
}

/**
 * Check if user has free shipping
 */
export function hasFreeShipping(badge) {
  if (!badge) return false;
  
  return badge.reward && (
    badge.reward.includes("Free Shipping") ||
    badge.reward.includes("Shipping") ||
    badge.tier === "Gold" ||
    badge.tier === "Platinum" ||
    badge.tier === "Diamond" ||
    badge.tier === "Legendary"
  );
}